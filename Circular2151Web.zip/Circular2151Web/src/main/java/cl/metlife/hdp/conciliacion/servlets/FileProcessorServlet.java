package cl.metlife.hdp.conciliacion.servlets;

import cl.blueprintsit.utils.files.FileUtils;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.List;

@WebServlet(urlPatterns = "/file-processing")
public class FileProcessorServlet extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(FileProcessorServlet.class);

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {



        /* The user is necessary for register who is trying to upload the conciliation file */
        /*User user = (User) request.getSession(true).getAttribute("user");
        if (user == null) {
            request.setAttribute("urlFrom", "/file-processing");
            request.getRequestDispatcher("/login").forward(request, response);
            return;
        }*/

        /* The Conciliation file is loaded */
        List<FileItem> fileItems;
        File excelFile;

        try {
            fileItems = FileUtils.getFileItemsFromRequest(request);
            excelFile = FileUtils.getUploadedFile(fileItems.get(0));
            //LOGGER.debug("Configuration file " + excelFile.getName() + " was successfully load to the server from remote OS.");

        } catch (FileUploadException e) {
            LOGGER.error("The configuration file was not loaded successfully." + e.getMessage());
            /*conciliationLog.fileNotUploadedLog(e.getMessage(), user);
            request.setAttribute("fileUploadError", "No se pudo cargar el archivo");
            request.getRequestDispatcher("/carga-archivo").forward(request, response);
            return;*/
            e.printStackTrace();
            return;
        }


        /* Validating if the file is empty */
        if(!excelFile.exists()) {
            request.setAttribute("fileUploadError", "Seleccionar archivo con informacion");
            request.getRequestDispatcher("/carga-archivo").forward(request, response);
            return;
        }

        String withoutBlankName = excelFile.getName().replace(" ", "_");

        /* Converting file content */
        String serializedFile = "";


        serializedFile = excelToCSV(excelFile);



        /* The file content is sent to the parser, if there are any problem trying to read it,
        the user is redirected to the upload page with an error notification */

        //ParsedBankFileType parsedCircularFile = null;




        //LOGGER.debug("Parsed successfully, redirecting to the Conciliation Process.");

        request.setAttribute("SerializedFile", serializedFile);
        //request.setAttribute("conciliationFileDescriptor", conciliationFileDescriptor);

        request.getRequestDispatcher("/serializedToXml").forward(request, response);
    }



    private String fileToString(File configurationFile) throws IOException {

        String output = "";

        FileReader fileReader = new FileReader(configurationFile);
        BufferedReader bufferedReader = new BufferedReader(fileReader);

        String line;

        while ((line = bufferedReader.readLine()) != null) {
            output += line + "\n";
        }
        bufferedReader.close();

        return output;
    }

    private String excelToCSV(File excelFile) {

        FileInputStream inp = null;
        String output = "";

        try {
            inp = new FileInputStream(excelFile);
            Workbook wb = WorkbookFactory.create(inp);

            for(int s=0; s<wb.getNumberOfSheets(); s++) {
                Sheet sheet = wb.getSheetAt(s);

                Row row = null;
                for (int i = 0; i <= sheet.getLastRowNum(); i++) {
                    row = sheet.getRow(i);

                    if(row.getCell(1) == null || String.valueOf(row.getCell(1)).isEmpty()) {
                        break;
                    }

                    for (int j = 0; j < row.getLastCellNum(); j++) {
                        Cell cell = row.getCell(j);
                        String cellValue;

                        if(cell == null) {
                            continue;
                        }

                        if(cell.getCellType() == Cell.CELL_TYPE_NUMERIC) {

                            if (DateUtil.isCellDateFormatted(cell)) {

                                SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                                cellValue = dateFormat.format(cell.getDateCellValue());
                            } else {
                                Double value = cell.getNumericCellValue();
                                Long longValue = value.longValue();
                                cellValue = longValue.toString();
                            }
                        } else {
                            cellValue = cell.getStringCellValue();
                        }

                        output = output.concat(cellValue + "·#");
                    }
                    output = output.concat("\n");
                }
            }
        } catch (InvalidFormatException e) {
            LOGGER.error("Invalid Format");
        } catch (IllegalStateException e) {
            LOGGER.error("Invalid Format");
        } catch (FileNotFoundException e) {
            LOGGER.error("File not found");
        } catch (IOException e) {
            LOGGER.error("IO Exception");
        } finally {
            try {
                inp.close();
            } catch (IOException e) {
                LOGGER.error("IO Exception" + e.getMessage());
            } catch (NullPointerException e) {
                LOGGER.error("Null File Input Stream " + e.getMessage());
            }
        }

        return output;
    }

    private String OLDbackupConciliationFile(String backupFilePath, String originalFileName, String serializedFile) {

        String backupFileName = "";

        try {
            backupFileName = System.currentTimeMillis() + "_" + originalFileName;

            /* Saving to file */
            File outputFile = new File(backupFilePath + backupFileName);
            outputFile.getParentFile().mkdirs();

            PrintWriter printWriter = new PrintWriter(outputFile);

            printWriter.print(serializedFile);
            printWriter.close();

        } catch (FileNotFoundException e) {
            LOGGER.error("The conciliation file could not be backed up in the specified path.");
        }

        return backupFileName;

    }


}
