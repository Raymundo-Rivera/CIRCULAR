package cl.metlife.circular2151.beans;

import cl.blueprintsit.utils.XML;
import cl.metlife.circular2151.dao.CircularDAO;
import cl.metlife.circular2151.entity.CirTabCir2151;
import org.apache.commons.lang3.StringEscapeUtils;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.el.ELContext;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by Blueprints on 6/25/2015.
 */

@ManagedBean(name="bppBean")
@SessionScoped
public class BusquedaPorPeriodoBean extends BaseBean implements Serializable {

    private static final long serialVersionUID = 1L;
    private List<CirTabCir2151> listaXmlPorPeriodo;

    @EJB
    public CircularDAO cirTabCirDato;


    @PostConstruct
    public void init(){
        ELContext elContext = FacesContext.getCurrentInstance().getELContext();
        BusquedaBean busquedaBean
                = (BusquedaBean) FacesContext.getCurrentInstance().getApplication()
                .getELResolver().getValue(elContext, null, "busquedaBean");

        this.setListaXmlPorPeriodo(cirTabCirDato.findByYear(busquedaBean.getAnoXml()));
    }

    public StreamedContent generarXmlPorPeriodo() throws IOException {
        FacesContext context = FacesContext.getCurrentInstance();
        ExternalContext ec = context.getExternalContext();

        HttpServletRequest req = (HttpServletRequest) ec.getRequest();
        PRT circular = new PRT();

        List<PRT.Registro> registros = circular.getRegistro();

        int registroId = 1;
        for(CirTabCir2151 reg : this.listaXmlPorPeriodo){
            PRT.Registro obj = new PRT.Registro();
            String periodo = reg.getPeriodo();
            periodo = periodo.substring(0,4);
            //String lineaDeNegocios = rs.getString("LINEA_DE_NEGOCIOS");
            String origen = reg.getOrigen();
            String base = reg.getBase();
            int grupo = reg.getGrupo();
            String cad = reg.getCod();
            if(cad == null) {
                cad = "";
            }

            obj.setCodigoUnico(registroId++);
            if(reg.getCircCodFormaRes() != null){
                obj.setFormaReserva(StringEscapeUtils.escapeHtml3(reg.getCircCodFormaRes()).trim());
            }

            obj.setGrupoCia(grupo);//valores validos: "1" o bien "2";

            if(reg.getLineaDeNegocios() != null){
                obj.setLineasNegocio(StringEscapeUtils.escapeHtml3(reg.getLineaDeNegocios()).trim());
            }

            if(reg.getDescProd() != null){
                obj.setNombreProducto(StringEscapeUtils.escapeHtml3(reg.getDescProd()).trim());
            }

            obj.setPeriodo(Integer.parseInt(periodo));

            if(reg.getCircPlazoSeguro() != null){
                obj.setPlazoSeguro(StringEscapeUtils.escapeHtml3(reg.getCircPlazoSeguro()).trim());
            }

            if(reg.getPol() != null){
                obj.setPoliza(StringEscapeUtils.escapeHtml3(reg.getPol()).trim());
            }

            obj.setPrimaDirecta((long) reg.getPrima());

            if(reg.getRamoCia() != null){
                obj.setRamoCia(StringEscapeUtils.escapeHtml3(reg.getRamoCia()).trim());
            }

            obj.setRamoEstFinanciero(reg.getRamoEstadoFinan());
            obj.setReservaTecnicaBruta((long) reg.getReservaBruta());
            obj.setReservaTecnicaNeta((long) reg.getReservaNeta());

            //RUT_CIA
            String rut = StringEscapeUtils.escapeHtml3(reg.getRutCia()).trim();
            rut = rut.replace("-", "").replace(" ", "").replace(".", "");
            obj.setRutCia(rut);

            if(reg.getCircTablaMortalidad() != null){
                obj.setTablaMor(StringEscapeUtils.escapeHtml3(reg.getCircTablaMortalidad()).trim());
            }

            if(obj.getTablaMor()==null) {
                obj.setTablaMor("");
            }

/*
Favor  puedes Cambia el nombre del campo Clausulas, por CAD/CAL , y ahí va el valor del campo COD de la tabla CIRC_TABLA_MORTALIDAD.

*/

            obj.setClausula(this.getClausulas(cad));

            registros.add(obj);
        }


        String xmlCircular = XML.marshall(circular);

        UtilsBean utils = new UtilsBean();
        InputStream stream = new ByteArrayInputStream( xmlCircular.getBytes() );

        ELContext elContext = FacesContext.getCurrentInstance().getELContext();
        BusquedaBean busquedaBean
                = (BusquedaBean) FacesContext.getCurrentInstance().getApplication()
                .getELResolver().getValue(elContext, null, "busquedaBean");

        StreamedContent file = new DefaultStreamedContent(stream, "xml", "xml_" + utils.getFormattedCurrentDate() + "_" + busquedaBean.getAnoXml() + ".xml");
        return file;
    }

    private List<PRT.Registro.Clausula> getClausulas(String cad) {
        List<String> clausulas = Arrays.asList(cad.split(","));
        List<PRT.Registro.Clausula> out = new ArrayList<PRT.Registro.Clausula>(clausulas.size());

        for(String clausula : clausulas) {
            if(!clausula.equals("")) {
                PRT.Registro.Clausula c = new PRT.Registro.Clausula();
                c.setNumero(clausula.trim());
                out.add(c);
            }
        }
        return out;
    }

    public List<CirTabCir2151> getListaXmlPorPeriodo() {
        return listaXmlPorPeriodo;
    }

    public void setListaXmlPorPeriodo(List<CirTabCir2151> listaXmlPorPeriodo) {
        this.listaXmlPorPeriodo = listaXmlPorPeriodo;
    }
}

