package cl.metlife.circular2151.business.authentication;

import cl.metlife.circular2151.business.authentication.wsautentifica.ServiceSoap_PortType;
import cl.metlife.circular2151.business.authentication.types.AuthenticationWsException;
import cl.metlife.circular2151.business.authentication.types.Person;
import org.apache.axis.message.MessageElement;
import cl.metlife.circular2151.business.authentication.wsautentifica.*;
import cl.metlife.circular2151.business.*;

import javax.xml.namespace.QName;
import javax.xml.rpc.ServiceException;
import java.net.MalformedURLException;
import java.rmi.RemoteException;
import java.util.List;

/**
 * Created by Ivan on 12-02-2015.
 */
public class AuthenticationManager {
    private final QName qname;
    private String wsdlUrl;
    ServiceSoap_PortType autPort;

    public static final String ADMIN_ROLE = "2151ADMIN";
    public static final String USER_ROLE = "2151USER";

    public AuthenticationManager(String wsdlUrl) throws MalformedURLException, ServiceException {
        this.wsdlUrl = wsdlUrl;
        this.qname = new QName("http://tempuri.org/", "Service");

        Service autService = new ServiceLocator(wsdlUrl, this.qname);
        autPort = autService.getServiceSoap();
        return;
    }

    public boolean isUserPasswordValid(RUT rut, String password) throws AuthenticationWsException {
        Check_claveResponseCheck_claveResult result = null;
        try {
            result = autPort.check_clave(rut.getNumber().toString(), password, "0", " ");
        } catch (RemoteException e) {
            e.printStackTrace();
            throw new AuthenticationWsException("Remote Exception while executing remote method check_clave. " + e.getMessage());
        }
        MessageElement[] msgContent = result.get_any();
        String xmlStr = null;
        try {
            xmlStr = msgContent[0].getAsString();
        } catch (Exception e) {
            e.printStackTrace();
            throw new AuthenticationWsException("Can't parse response. " + e.getMessage());
        }

        String status = xml.xpathExtractor(xmlStr, "/autentificacion/status/text()");
        String error = xml.xpathExtractor(xmlStr, "/autentificacion/error/text()");
        String mensaje = xml.xpathExtractor(xmlStr, "/autentificacion/mensaje/text()");


        if("OK".equalsIgnoreCase(status)){
            return true;
        }
        else if("NOK".equalsIgnoreCase(status)) {
            return false;

        }
        throw new AuthenticationWsException("Error desconocido: " + error + "msj: " + mensaje);
    }

    public List<String> getUsersPersmissions(RUT rut) throws AuthenticationWsException {
        String idApp = "INT";
        String rutStr = rut.getNumber().toString() + rut.getVerifierNumber();
        ROLES_PERSONA_RUT_APLICResponseROLES_PERSONA_RUT_APLICResult result;
        try {
            result = autPort.ROLES_PERSONA_RUT_APLIC(idApp, rutStr);
        } catch (RemoteException e) {
            e.printStackTrace();
            throw new AuthenticationWsException("Remote Exception while executing remote method ROLES_PERSONA_RUT_APLIC. " + e.getMessage());
        }


        MessageElement[] msgContent = result.get_any();
        String xmlStr = null;
        try {
            xmlStr = msgContent[0].getAsString();
        } catch (Exception e) {
            e.printStackTrace();
            throw new AuthenticationWsException("Can't parse response. " + e.getMessage());
        }

        //
        List<String> r = xml.xpathListExtractor(xmlStr, "/NewDataSet/Table/ROL_CODIGO/text()");

        return r;
    }

    public boolean rutHasPermission(RUT rut, String permissionName) throws AuthenticationWsException {
        List<String> permissions = this.getUsersPersmissions(rut);
        for(String p : permissions) {
            if(p.equals(permissionName)){
                return true;
            }
        }
        return false;
    }

    public Person getPerson(RUT rut) throws AuthenticationWsException, InvalidRUTException {
        Sp_info_personaResponseSp_info_personaResult result;
        try {
            result = autPort.sp_info_persona(rut.getNumber().toString());
        } catch (RemoteException e) {
            e.printStackTrace();
            throw new AuthenticationWsException("Remote Exception while executing remote method. sp_info_persona" + e.getMessage());
        }
        MessageElement[] elements = result.get_any();
        String xmlStr = null;
        try {
            xmlStr = elements[1].getAsString();
        } catch (Exception e) {
            e.printStackTrace();
        }


        Person p = new Person();
        p.setName(xml.xpathExtractor(xmlStr, "//NOMBRES/text()") + " " +
                xml.xpathExtractor(xmlStr, "//APPAT/text()") + " " +
                xml.xpathExtractor(xmlStr, "//APMAT/text()"));
        p.setEmail(xml.xpathExtractor(xmlStr, "//CORREOELECTRONICO/text()"));
        /* FIXME */
        RUT rut2 = RUT.parseRUT(xml.xpathExtractor(xmlStr, "//RUT/text()") + "-" + xml.xpathExtractor(xmlStr, "//DVRUT/text()"));
        p.setRut(rut2);
        p.setUsername(p.getEmail().split("@")[0]);
        return p;

    }
}
