package cl.metlife.circular2151.beans;

import cl.metlife.circular2151.dao.CirTabExcelOriginDAO;
import cl.metlife.circular2151.dao.CirTabSabDAO;
import cl.metlife.circular2151.entity.CirTabExcelOrigenCir2151;
import cl.metlife.circular2151.entity.CirTabSab2151;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by Blueprints on 6/25/2015.
 */

@ManagedBean(name="revisionBean")
@ViewScoped
public class RevisionConfirmacionBean extends BaseBean implements Serializable {

    private static final long serialVersionUID = 1L;

    /* Tabla */
    public List<HashMap> hashList;
    // Mostrar tabla
    public boolean mostrarTabla;


    /* Obtener lineas de negocio */
    private List<String> lineasDeNegocio;

    /* Busqueda */
    private String ano;

    @EJB
    public CirTabSabDAO cirTabSabDAO;


    @PostConstruct
    public void init(){
        lineasDeNegocio = cirTabSabDAO.findAllLineasDeNegocio();
        hashList = new ArrayList<HashMap>();
        this.mostrarTabla = false;
    }

    public List<String> getAllAnos() {
        List<String> anoMes = cirTabSabDAO.findAllPeriods();
        List<String> anos  = new ArrayList<String>();

        for (String anoMe : anoMes) {
            String ano = anoMe.substring(0, 4);

            if(!anos.contains(ano)){
                anos.add(ano);
            }
        }

        return anos;
    }

    public void clickBuscar(){
        HashMap<String, ResumenLineaDeNegocio> dataEnero = cirTabSabDAO.findDataByPeriodo(ano , "01");
        HashMap<String, ResumenLineaDeNegocio> dataFebrero = cirTabSabDAO.findDataByPeriodo(ano, "02");
        HashMap<String, ResumenLineaDeNegocio> dataMarzo = cirTabSabDAO.findDataByPeriodo(ano, "03");
        HashMap<String, ResumenLineaDeNegocio> dataAbril = cirTabSabDAO.findDataByPeriodo(ano, "04");
        HashMap<String, ResumenLineaDeNegocio> dataMayo = cirTabSabDAO.findDataByPeriodo(ano, "05");
        HashMap<String, ResumenLineaDeNegocio> dataJunio = cirTabSabDAO.findDataByPeriodo(ano, "06");
        HashMap<String, ResumenLineaDeNegocio> dataJulio = cirTabSabDAO.findDataByPeriodo(ano, "07");
        HashMap<String, ResumenLineaDeNegocio> dataAgosto = cirTabSabDAO.findDataByPeriodo(ano, "08");
        HashMap<String, ResumenLineaDeNegocio> dataSeptiembre = cirTabSabDAO.findDataByPeriodo(ano, "09");
        HashMap<String, ResumenLineaDeNegocio> dataOctubre = cirTabSabDAO.findDataByPeriodo(ano, "10");
        HashMap<String, ResumenLineaDeNegocio> dataNoviembre = cirTabSabDAO.findDataByPeriodo(ano, "11");
        HashMap<String, ResumenLineaDeNegocio> dataDiciembre = cirTabSabDAO.findDataByPeriodo(ano, "12");

        this.hashList.add(dataEnero);
        this.hashList.add(dataFebrero);
        this.hashList.add(dataMarzo);
        this.hashList.add(dataAbril);
        this.hashList.add(dataMayo);
        this.hashList.add(dataJunio);
        this.hashList.add(dataJulio);
        this.hashList.add(dataAgosto);
        this.hashList.add(dataSeptiembre);
        this.hashList.add(dataOctubre);
        this.hashList.add(dataNoviembre);
        this.hashList.add(dataDiciembre);

        this.mostrarTabla = true;
    }

    public List<HashMap> getHashList() {
        return hashList;
    }

    public void setHashList(List<HashMap> hashList) {
        this.hashList = hashList;
    }

    public String getAno() {
        return ano;
    }

    public void setAno(String ano) {
        this.ano = ano;
    }

    public int allLineasDeNegocioSize() {
        return lineasDeNegocio.size();
    }

    public List<String> getAllLineasDeNegocio() {
        return lineasDeNegocio;
    }

    public boolean isMostrarTabla() {
        return mostrarTabla;
    }

    public void setMostrarTabla(boolean mostrarTabla) {
        this.mostrarTabla = mostrarTabla;
    }
}

