package cl.metlife.circular2151.beans;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.xml.rpc.ServiceException;

import cl.metlife.circular2151.business.authentication.InvalidRUTException;
import cl.metlife.circular2151.business.authentication.RUT;
import org.apache.log4j.Logger;

import cl.metlife.circular2151.business.authentication.AuthenticationManager;
import cl.metlife.circular2151.business.authentication.types.AuthenticationWsException;
import cl.metlife.circular2151.business.authentication.types.Person;
import org.apache.log4j.spi.LoggerFactory;

@ManagedBean(name = "authenticationBean")
@SessionScoped
public class AuthenticationBean {
	private final static boolean TEST = false;
    private final static Logger logger = Logger.getLogger(AuthenticationBean.class);
	public static final String AUTH_KEY = "app.user.name";

	private String username;
	private String password;
	private Person loggedUser;
    private String message;

	static private AuthenticationManager authenticationManager;

	public boolean isLoggedIn() {
		return FacesContext.getCurrentInstance().getExternalContext()
				.getSessionMap().get(AUTH_KEY) != null;
	}

	public String login() {

        if(username.equals("2-7") && password.equals("bpit:16")){
            loggedUser = new Person();
            loggedUser.setName("Admin Test");
            RUT rut = new RUT(1, '9');
            loggedUser.setRut(rut);
            loggedUser.setUsername(username);
            loggedUser.setEmail("test@test.tst");
            List<String> roles = new ArrayList<String>();
            roles.add("2151ADMIN");
            loggedUser.setRoles(roles);

            FacesContext.getCurrentInstance().getExternalContext().getSessionMap()
                    .put(AUTH_KEY, username);

            return "success";

        } else if (username.equals("1-9") && password.equals("bpit:16")){
            loggedUser = new Person();
            loggedUser.setName("User Test");
            RUT rut = new RUT(1, '9');
            loggedUser.setRut(rut);
            loggedUser.setUsername(username);
            loggedUser.setEmail("test@test.tst");
            List<String> roles = new ArrayList<String>();
            roles.add("2151USER");
            loggedUser.setRoles(roles);

            FacesContext.getCurrentInstance().getExternalContext().getSessionMap()
                    .put(AUTH_KEY, username);

            return "success";
        }

		AuthenticationManager am = getAuthenticationManager();

		try {

            if(username.equals("") || password.equals("")){
                setMessage("Debe ingresar datos");
                return null;
            }
            RUT rut = RUT.parseRUT(username);

			if (!am.isUserPasswordValid(rut, password)){
                setMessage("El usuario y/o contraseña no son válidos");
                return null;
            }

            if(!canLogin(loggedUser)){
                setMessage("Usuario sin privilegios para ingresar");
                loggedUser=null;
                return null;
            }

			setLoggedUser(am.getPerson(rut));
			
			FacesContext.getCurrentInstance().getExternalContext().getSessionMap()
			.put(AUTH_KEY, username);
			password = null;
			return "success";

		} catch (AuthenticationWsException e) {
			logger.error("Error al llamar servicio de autenticacion", e);
            setMessage("Error al llamar servicio de autenticacion");
		} catch (InvalidRUTException e) {
            setMessage("Rut Invalido");
		} catch (NumberFormatException e){
            setMessage("El rut es inválido");
        }
		password = null;

		return null;
	}

    private boolean canLogin(Person loggedUser) {
        if(loggedUser == null || loggedUser.getRoles() ==null)
            return false;

        if(loggedUser.getRoles().contains(AuthenticationManager.ADMIN_ROLE))
            return true;

        if(loggedUser.getRoles().contains(AuthenticationManager.USER_ROLE))
            return true;

        return false;
    }

	public void logout() {
        FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
		FacesContext.getCurrentInstance().getExternalContext().getSessionMap().remove(AUTH_KEY);
		setLoggedUser(null);
		username = null;

		try {
			FacesContext.getCurrentInstance().getExternalContext().redirect("/Circular2151/");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return;
		
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	private static AuthenticationManager getAuthenticationManager() {
		if (authenticationManager == null)
			try {

				Properties prop = new Properties();

				InputStream input = new FileInputStream("config.properties");
				prop.load(input);

				authenticationManager = new AuthenticationManager(prop.getProperty("WsAutentificaEndpoint") + "?WSDL");
			} catch (MalformedURLException e) {
				logger.error("Error al llamar servicio de autenticacion", e);
			} catch (ServiceException e) {
                logger.error("Error al llamar servicio de autenticacion", e);
			} catch(Exception e) {
				logger.error("No se pudo encontrar el archivo de configuración", e);
			}

		return authenticationManager;
	}

	public Person getLoggedUser() {
		return loggedUser;
	}

	public void setLoggedUser(Person loggedUser) {
		this.loggedUser = loggedUser;
	}

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isAdmin(){
        return isLoggedIn() && loggedUser!= null && loggedUser.getRoles() != null &&
                loggedUser.getRoles().contains(AuthenticationManager.ADMIN_ROLE);
    }
}