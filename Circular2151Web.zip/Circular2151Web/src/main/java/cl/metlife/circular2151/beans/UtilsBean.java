package cl.metlife.circular2151.beans;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by Blueprints on 6/25/2015.
 */

@ManagedBean(name="utilsBean")
@ViewScoped
public class UtilsBean extends BaseBean implements Serializable {

    private String formattedCurrentDate;

    public String getFormattedCurrentDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy");
        return sdf.format(new Date());
    }

}

