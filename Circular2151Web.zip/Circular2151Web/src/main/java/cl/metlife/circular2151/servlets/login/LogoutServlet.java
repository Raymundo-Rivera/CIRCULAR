package cl.metlife.circular2151.servlets.login;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(urlPatterns = "/logout")
public class LogoutServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        /* The the user was authenticated, then now he will be no longer */
        if (req.getSession() != null && req.getSession().getAttribute("user") != null){
            req.getSession().removeAttribute("user");
        }

        /* And all the way, he is going to be redirected to the login page */
        req.getRequestDispatcher("/login").forward(req, resp);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }
}
