package cl.metlife.circular2151.beans;

import cl.blueprintsit.utils.XML;
import cl.metlife.circular2151.dao.CirTabExcelOriginDAO;
import cl.metlife.circular2151.dao.CirTabSabDAO;
import cl.metlife.circular2151.dao.CircularDAO;
import cl.metlife.circular2151.entity.CirTabCir2151;
import cl.metlife.circular2151.entity.CirTabExcelOrigenCir2151;
import cl.metlife.circular2151.entity.CirTabSab2151;
import cl.metlife.circular2151.estructurasalida.Circular2151;
import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.primefaces.component.selectbooleanbutton.SelectBooleanButton;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.el.ELContext;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.bean.ViewScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.text.DecimalFormat;
import java.util.*;

/**
 * Created by Blueprints on 6/25/2015.
 */

@ManagedBean(name="busquedaBean")
@SessionScoped
public class BusquedaBean extends BaseBean implements Serializable {

    private static final long serialVersionUID = 1L;

    /* Booleans para mostrar elementos en la vista */
    private boolean mostrarTabla;
    private boolean readOnly;
    private boolean desactivarBotonOtraBusqueda;

    /* Parametros de búsqueda */
    private String anoPeriodo;
    private String mesPeriodo;
    private String lineaDeNegocio;
    private String origen;
    private String tipoDeDato;
    private ArrayList<SelectItem> listaTipoDato;

    /* Lineas de negocio */
    private List<String> lineasDeNegocio;
    /* Origenes */
    private List<String> origenes;

    /* Periodo Generacion XML */
    private String anoXml;

    /* Hash que guarda año y su lista de meses */
    private HashMap<String, List<String>> hashAnoMes;

    /* Datos de la tabla */
    private List<Circular2151> listaDatos;
    private List<CirTabCir2151> listaXmlPorPeriodo;
    private List<CirTabCir2151> listaXmlDeExcel;
    /* boolean para descargar XML */
    private boolean mostrarBotonExcelToXml;

    /* Data Access Object */
    @EJB
    public CirTabSabDAO cirTabSabDao;

    @EJB
    public CircularDAO cirTabCirDato;

    @EJB
    public CirTabExcelOriginDAO excelDao;


    /* Metodo que inicializa variables */
    @PostConstruct
    public void init(){
        this.listaDatos = new ArrayList<Circular2151>();
        this.readOnly = false;
        this.mostrarBotonExcelToXml = false;
        this.desactivarBotonOtraBusqueda = true;
        this.mostrarTabla = false;
        this.listaTipoDato = new ArrayList<SelectItem>();
        listaTipoDato.add(new SelectItem("P", "Prima"));
        listaTipoDato.add(new SelectItem("R", "Reserva"));

        this.tipoDeDato = "P";

        // Buscar lineas de negocio.
        //lineasDeNegocio = cirTabSabDao.findBusinessLinesCodes();

        getAllPeriodos();
    }

    /* Click en continuar */
    public void clickContinuar(){
        if(anoPeriodo.equals("")){
            showError("Error", "Debe ingresar el año para realizar una búsqueda.");
            return;
        }

        readOnly = true;
        desactivarBotonOtraBusqueda = false;

        if(this.tipoDeDato.equals("P")){
            if(!mesPeriodo.equals("")){
                listaDatos = cirTabSabDao.findPrimaData(anoPeriodo + mesPeriodo, lineaDeNegocio, origen);
            } else {
                listaDatos = cirTabSabDao.findPrimaData(anoPeriodo, lineaDeNegocio, origen);
            }

            if(listaDatos.size() > 0){
                showInfo("Busqueda satisfactoria", "Se encontro " + listaDatos.size() + " registro(s)");
            } else {
                showWarn("Aviso", "No existen registros asociados a la busqueda");
            }
        } else if (this.tipoDeDato.equals("R")) {
            if(!mesPeriodo.equals("")){
                listaDatos = cirTabSabDao.findReservaData(anoPeriodo + mesPeriodo, lineaDeNegocio, origen);
            } else {
                listaDatos = cirTabSabDao.findReservaData(anoPeriodo, lineaDeNegocio, origen);
            }

            if(listaDatos.size() > 0){
                showInfo("Busqueda satisfactoria", "Se encontro " + listaDatos.size() + " registro(s)");
            } else {
                showWarn("Aviso", "No existen registros asociados a la busqueda");
            }
            showInfo("Aviso", "Se efectuo la busqueda de forma satisfactoria");
        } else if (this.tipoDeDato.equals("")) {
            showError("Error", "Debe ingresar el tipo de dato");
            return;
        }

        this.mostrarTabla = true;
    }

    private void isApproved(List<Object> listaDatos) {

    }

    public List<String> getAllAnos() {
        ArrayList<String> a = new ArrayList<String>();
        a.addAll(hashAnoMes.keySet());

        Collections.sort(a,new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                if(o1 == null)
                    return -1;
                return -o1.compareTo(o2);
            }
        });

        return a;
    }

    public List<String> getMesesByAno(){
        List<String> response = hashAnoMes.get(anoPeriodo);
        if(response == null)
            return response;
        else
            Collections.sort(response,new Comparator<String>() {
                @Override
                public int compare(String o1, String o2) {
                    if(o1 == null)
                        return -1;
                    return -o1.compareTo(o2);
                }
            });
        return response;
    }

    public List<String> getMesesByAnoXml(){
        List<String> response = hashAnoMes.get(anoXml);
        if(response == null)
            return response;
        else
            Collections.sort(response);
        return response;
    }

    public void changeAno(){
        lineasDeNegocio = cirTabSabDao.findBusinessLinesCodesByAno(anoPeriodo);
    }

    public void changeLinea(){
        origenes = cirTabSabDao.findOriginsByLineaAndAno(lineaDeNegocio, anoPeriodo);
    }

    public HashMap<String, List<String>> getAllPeriodos() {
        List<String> listaPeriodos = cirTabSabDao.findAllPeriods();
        hashAnoMes = new HashMap<String, List<String>>();

        for (String listaPeriodo : listaPeriodos) {
            String año, mes;

            año = listaPeriodo.substring(0,4);
            mes = listaPeriodo.substring(4,6);

            if(!hashAnoMes.containsKey(año)){
                List<String> meses = new ArrayList<String>();
                meses.add(mes);
                hashAnoMes.put(año, meses);
            } else {
                hashAnoMes.get(año).add(mes);
            }
        }

        return hashAnoMes;
    }

    public List<String> getAllLineas() {
        return cirTabSabDao.findBusinessLinesCodes();
    }

    public List<String> getAllOrigen() {
        return cirTabSabDao.findOriginCodes();
    }

    public void confirmarDatos(){
        cirTabSabDao.confirmData(anoPeriodo + mesPeriodo, lineaDeNegocio, origen);
        for (Circular2151 listaDato : listaDatos) {
            listaDato.setConfirmed(true);
        }
        addMessage("Aviso", "Se han confirmado " + listaDatos.size() + " registros");
    }

    public void otraBusqueda() {
        mostrarTabla = false;
        readOnly = false;
        desactivarBotonOtraBusqueda = true;
    }

    public void handleFileUpload(FileUploadEvent event) {
        FacesContext context = FacesContext.getCurrentInstance();

        if (event.getFile().equals(null)) {
            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "File is null", null));
        }
        InputStream file;
        HSSFWorkbook workbook = null;
        try {
            file = event.getFile().getInputstream();
            workbook = new HSSFWorkbook(file);
        } catch (IOException e) {
            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error reading file" + e, null));
        }

        HSSFSheet sheet = workbook.getSheetAt(0);

        Iterator<Row> rowIterator = sheet.iterator();
        Calendar calendar = new GregorianCalendar();
        List<CirTabSab2151> lista = new ArrayList<CirTabSab2151>();

        for(Row row : sheet) {
            CirTabSab2151 fila = new CirTabSab2151();

            if(row.getRowNum()==0){
                continue; //just skip the rows if row number is 0
            }

            for(int cn=0; cn<row.getLastCellNum(); cn++) {

                if(row.getRowNum()==0){
                    continue; //just skip the rows if row number is 0
                }
                // If the cell is missing from the file, generate a blank one
                // (Works by specifying a MissingCellPolicy)
                Cell cell = row.getCell(cn, Row.CREATE_NULL_AS_BLANK);

                if(cn == 0){
                    String per = "" + getNumericValue(cell);
                    int posicionPunto = per.indexOf('.');
                    fila.setPeriodo(per.substring(0, posicionPunto));
                } else if(cn == 1){
                    double d = getNumericValue(cell);
                    DecimalFormat decimalFormat = new DecimalFormat("#");
                    fila.setRutCia("" + decimalFormat.format(d));
                } else if(cn == 2){
                    String per = "" + getNumericValue(cell);
                    int posicionPunto = per.indexOf('.');
                    fila.setGrpCia(per.substring(0, posicionPunto));
                } else if(cn == 3){
                    String per = "" + getNumericValue(cell);
                    int posicionPunto = per.indexOf('.');
                    fila.setCodLob(per.substring(0, posicionPunto));
                } else if(cn == 4){
                    fila.setLinea(getStringValue(cell));
                } else if(cn == 5){
                    String per = "" + getNumericValue(cell);
                    int posicionPunto = per.indexOf('.');
                    fila.setCanalventa(per.substring(0, posicionPunto));
                } else if(cn == 6){
                    fila.setBase(getStringValue(cell));
                } else if(cn == 7){
                    double d = getNumericValue(cell);
                    DecimalFormat decimalFormat = new DecimalFormat("#");
                    fila.setPoliza("" + decimalFormat.format(d));
                } else if(cn == 8){
                    String per = "" + getNumericValue(cell);
                    int posicionPunto = per.indexOf('.');
                    fila.setCodFecu(per.substring(0, posicionPunto));
                } else if(cn == 9){
                    String per = "" + getNumericValue(cell);
                    int posicionPunto = per.indexOf('.');
                    fila.setCodProd(per.substring(0, posicionPunto));
                } else if(cn == 10){
                    fila.setDscProd(getStringValue(cell));
                } else if(cn == 11){
                    fila.setCodPol(getStringValue(cell));
                } else if(cn == 12){
                    fila.setCodCad(getStringValue(cell));
                } else if(cn == 13){
                    fila.setCodFormaRes(getStringValue(cell));
                } else if(cn == 14){
                    fila.setPlazoSeguro(getStringValue(cell));
                } else if(cn == 15){
                    fila.setTablaMortalidad(String.valueOf(getNumericValue(cell)));
                } else if(cn == 16){
                    fila.setReserva(getNumericValue(cell));
                } else if(cn == 17){
                    fila.setPrima(getNumericValue(cell));
                } else if(cn == 18){
                    fila.setTipoDato(getStringValue(cell));
                } else if(cn == 19){
                    fila.setReservaBrutaPs(getNumericValue(cell));
                } else if(cn == 20){
                    fila.setReservasNetaPs(getNumericValue(cell));
                } else if(cn == 21){
                    fila.setPrimaPs((long) getNumericValue(cell));
                } else if(cn == 22){
                    fila.setReservaNeta(getNumericValue(cell));
                } else if(cn == 23){
                    fila.setPorcCedido(getNumericValue(cell));
                } else if(cn == 24){
                    fila.setCodCobe(getStringValue(cell));
                }  else if(cn == 25){
                    fila.setOrigen("EXCEL"); // FIXME : Quizas este valor cambie
                } else if(cn == 26){
                    fila.setLineaNegocio(getStringValue(cell));
                } else if(cn == 27){
                    /*fila.setCirTabExcelOrigenCir2151(getStringValue(cell));*/ // TODO
                } else if(cn == 28){
                    fila.setAprobado(getStringValue(cell));
                } else if(cn == 39){
                    fila.setUsuarioAprueba(getStringValue(cell));
                }
            }

            lista.add(fila);
        }

        for (CirTabSab2151 cirTabSab2151 : lista) {
            cirTabSab2151.setCirTabSab2151Id(null);

            CirTabExcelOrigenCir2151 origenExcel = new CirTabExcelOrigenCir2151();
            origenExcel.setNombreArchivo(event.getFile().getFileName());
            origenExcel.setSubido(new Date());// Cambié de Calendar.getInstance() a new Date()
            origenExcel.setUsuario(super.getLoggedUserName());
            origenExcel.setCirTabExcelOrigenCir2151(null);

            cirTabSab2151.setCirTabExcelOrigenCir2151(origenExcel);

            /* Escribiendo la tabla CirTabExcelOrigin */
            CirTabExcelOrigenCir2151 origenExcelPersist = excelDao.create(origenExcel);

            /* Escribiendo la tabla CirTabSab*/
            cirTabSab2151.setCirTabExcelOrigenCir2151(origenExcelPersist); // Agregandole el objeto persistido
            cirTabSabDao.create(cirTabSab2151);
        }

        addMessage("Carga satisfactoria", "Se subieron correctamente " + lista.size() + " registros");

    }

    public String mostrarDatosXmlPorPeriodo(){
        if(this.anoXml.equals("")){
            showError("Error", "Debe ingresar el periodo");
            return null;
        } else {
            return "/views/BusquedaPorPeriodo.xhtml";
        }
    }

    public void generarXmlDeExcel(FileUploadEvent event){
        FacesContext context = FacesContext.getCurrentInstance();

        if (event.getFile().equals(null)) {
            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "File is null", null));
        }
        InputStream file;
        HSSFWorkbook workbook = null;
        try {
            file = event.getFile().getInputstream();
            workbook = new HSSFWorkbook(file);
        } catch (IOException e) {
            context
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error reading file" + e, null));
        }

        HSSFSheet sheet = workbook.getSheetAt(0);

        Iterator<Row> rowIterator = sheet.iterator();
        Calendar calendar = new GregorianCalendar();
        List<CirTabCir2151> lista = new ArrayList<CirTabCir2151>();


        for(Row row : sheet) {
            CirTabCir2151 fila = new CirTabCir2151();

            if(row.getRowNum()==0){
                continue; //just skip the rows if row number is 0
            }

            for(int cn=0; cn<row.getLastCellNum(); cn++) {

                if(row.getRowNum()==0){
                    continue; //just skip the rows if row number is 0
                }
                // If the cell is missing from the file, generate a blank one
                // (Works by specifying a MissingCellPolicy)
                Cell cell = row.getCell(cn, Row.CREATE_NULL_AS_BLANK);

                if(cn == 0){
                    if(cell.getCellType() == 1){
                        fila.setRutCia("" + getStringValue(cell));
                    } else {
                        fila.setRutCia("" + (int) (Double.parseDouble("" + getNumericValue(cell))));
                    }
                } else if(cn == 1){
                    if(cell.getCellType() == 1){
                        try{
                            fila.setGrupo(Integer.parseInt(getStringValue(cell)));
                        } catch (NumberFormatException numberFormatException){
                            this.mostrarBotonExcelToXml = false;
                            super.showError("Error", "La columna \"Grupo\" de la fila " + (cell.getRow().getRowNum() + 1) + " debe ser numérica");
                            System.out.println("La columna \"Grupo\" de la fila " + (cell.getRow().getRowNum() + 1) + " debe ser numérica");
                            return;
                        }
                    } else {
                        fila.setGrupo((int) getNumericValue(cell));
                    }
                } else if(cn == 2){
                    if(cell.getCellType() == 1){
                        fila.setPeriodo(getStringValue(cell));
                    } else {
                        fila.setPeriodo("" +getNumericValue(cell));
                    }
                } else if(cn == 3){
                    if(cell.getCellType() == 1){
                        fila.setLineaDeNegocios(getStringValue(cell));
                    } else {
                        fila.setLineaDeNegocios("" +getNumericValue(cell));
                    }
                } else if(cn == 4){
                    if(cell.getCellType() == 1){
                        try {
                            fila.setRamoEstadoFinan(Integer.parseInt(getStringValue(cell)));
                        } catch (NumberFormatException numberFormatException){
                            this.mostrarBotonExcelToXml = false;
                            super.showError("Error", "La columna \"RamoEstadoFinanciero\" de la fila " + (cell.getRow().getRowNum() + 1) + " debe ser numérica");
                            System.out.println("La columna \"RamoEstadoFinanciero\" de la fila " + (cell.getRow().getRowNum() + 1) + " debe ser numérica");
                            return;
                        }
                    } else {
                        fila.setRamoEstadoFinan((int) getNumericValue(cell));
                    }
                } else if(cn == 5){
                    if(cell.getCellType() == 1){
                        fila.setRamoCia(getStringValue(cell));
                    } else {
                        fila.setRamoCia("" +getNumericValue(cell));
                    }
                } else if(cn == 6){
                    if(cell.getCellType() == 1){
                        fila.setDescProd(getStringValue(cell));
                    } else {
                        fila.setDescProd("" +getNumericValue(cell));
                    }
                } else if(cn == 7){
                    if(cell.getCellType() == 1){
                        fila.setPol(getStringValue(cell));
                    } else {
                        fila.setPol("" +getNumericValue(cell));
                    }
                } else if(cn == 8){
                    if(cell.getCellType() == 1){
                        fila.setCod(getStringValue(cell));
                    } else {
                        fila.setCod("" +getNumericValue(cell));
                    }
                } else if(cn == 9){
                    if(cell.getCellType() == 1){
                        try {
                            fila.setPrima(Double.parseDouble(getStringValue(cell)));
                        } catch (NumberFormatException numberFormatException){
                            this.mostrarBotonExcelToXml = false;
                            super.showError("Error", "La columna \"Prima\" de la fila " + (cell.getRow().getRowNum() + 1) + " debe ser numérica");
                            System.out.println("La columna \"Prima\" de la fila " + (cell.getRow().getRowNum() + 1) + " debe ser numérica");
                            return;
                        }
                    } else {
                        fila.setPrima(getNumericValue(cell));
                    }
                } else if(cn == 10){
                    if(cell.getCellType() == 1){
                        fila.setCircCodFormaRes(getStringValue(cell));
                    } else {
                        fila.setCircCodFormaRes("" +getNumericValue(cell));
                    }
                } else if(cn == 11){
                    if(cell.getCellType() == 1){
                        try {
                            fila.setReservaBruta(Double.parseDouble(getStringValue(cell)));
                        } catch (NumberFormatException numberFormatException){
                            this.mostrarBotonExcelToXml = false;
                            super.showError("Error", "La columna \"ReservaBruta\" de la fila " + (cell.getRow().getRowNum() + 1) + " debe ser numérica");
                            System.out.println("La columna \"ReservaBruta\" de la fila " + (cell.getRow().getRowNum() + 1) + " debe ser numérica");
                            return;
                        }
                    } else {
                        fila.setReservaBruta(getNumericValue(cell));
                    }
                } else if(cn == 12){
                    if(cell.getCellType() == 1){
                        try {
                            fila.setReservaNeta(Double.parseDouble(getStringValue(cell)));
                        } catch (NumberFormatException numberFormatException){
                            this.mostrarBotonExcelToXml = false;
                            super.showError("Error", "La columna \"ReservaNeta\" de la fila " + (cell.getRow().getRowNum() + 1) + " debe ser numérica");
                            System.out.println("La columna \"ReservaNeta\" de la fila " + (cell.getRow().getRowNum() + 1) + " debe ser numérica");
                            return;
                        }
                    } else {
                        fila.setReservaNeta(getNumericValue(cell));
                    }
                } else if(cn == 13){
                    if(cell.getCellType() == 1){
                        fila.setCircPlazoSeguro(getStringValue(cell));
                    } else {
                        fila.setCircPlazoSeguro("" +getNumericValue(cell));
                    }
                } else if(cn == 14){
                    if(cell.getCellType() == 1){
                        fila.setCircTablaMortalidad(getStringValue(cell));
                    } else {
                        fila.setCircTablaMortalidad("" +getNumericValue(cell));
                    }
                }
            }

            lista.add(fila);
        }

        this.listaXmlDeExcel = lista;
        this.mostrarBotonExcelToXml = true;
    }

    public StreamedContent generarXmlDeExcel() throws IOException {
        FacesContext context = FacesContext.getCurrentInstance();
        ExternalContext ec = context.getExternalContext();

        HttpServletRequest req = (HttpServletRequest) ec.getRequest();
        PRT circular = new PRT();

        List<PRT.Registro> registros = circular.getRegistro();

        int registroId = 1;
        for(CirTabCir2151 reg : this.listaXmlDeExcel){
            PRT.Registro obj = new PRT.Registro();
            String periodo = reg.getPeriodo();
            periodo = periodo.substring(0,4);
            //String lineaDeNegocios = rs.getString("LINEA_DE_NEGOCIOS");
            String origen = reg.getOrigen();
            String base = reg.getBase();
            int grupo = reg.getGrupo();
            String cad = reg.getCod();
            if(cad == null) {
                cad = "";
            }

            obj.setCodigoUnico(registroId++);
            if(reg.getCircCodFormaRes() != null){
                obj.setFormaReserva(StringEscapeUtils.escapeHtml3(reg.getCircCodFormaRes()).trim());
            }

            obj.setGrupoCia(grupo);//valores validos: "1" o bien "2";

            if(reg.getLineaDeNegocios() != null){
                obj.setLineasNegocio(StringEscapeUtils.escapeHtml3(reg.getLineaDeNegocios()).trim());
            }

            if(reg.getDescProd() != null){
                obj.setNombreProducto(StringEscapeUtils.escapeHtml3(reg.getDescProd()).trim());
            }

            obj.setPeriodo(Integer.parseInt(periodo));

            if(reg.getCircPlazoSeguro() != null){
                obj.setPlazoSeguro(StringEscapeUtils.escapeHtml3(reg.getCircPlazoSeguro()).trim());
            }

            if(reg.getPol() != null){
                obj.setPoliza(StringEscapeUtils.escapeHtml3(reg.getPol()).trim());
            }

            obj.setPrimaDirecta((long) reg.getPrima());

            if(reg.getRamoCia() != null){
                obj.setRamoCia(StringEscapeUtils.escapeHtml3(reg.getRamoCia()).trim());
            }

            obj.setRamoEstFinanciero(reg.getRamoEstadoFinan());
            obj.setReservaTecnicaBruta((long) reg.getReservaBruta());
            obj.setReservaTecnicaNeta((long) reg.getReservaNeta());

            //RUT_CIA
            String rut = StringEscapeUtils.escapeHtml3(reg.getRutCia()).trim();
            rut = rut.replace("-", "").replace(" ", "").replace(".", "");
            obj.setRutCia(rut);

            if(reg.getCircTablaMortalidad() != null){
                obj.setTablaMor(StringEscapeUtils.escapeHtml3(reg.getCircTablaMortalidad()).trim());
            }

            if(obj.getTablaMor()==null) {
                obj.setTablaMor("");
            }

/*
Favor  puedes Cambia el nombre del campo Clausulas, por CAD/CAL , y ahí va el valor del campo COD de la tabla CIRC_TABLA_MORTALIDAD.

*/

            obj.setClausula(this.getClausulas(cad));

            registros.add(obj);
        }


        String xmlCircular = XML.marshall(circular);

        UtilsBean utils = new UtilsBean();
        InputStream stream = new ByteArrayInputStream( xmlCircular.getBytes() );

        ELContext elContext = FacesContext.getCurrentInstance().getELContext();
        BusquedaBean busquedaBean
                = (BusquedaBean) FacesContext.getCurrentInstance().getApplication()
                .getELResolver().getValue(elContext, null, "busquedaBean");

        StreamedContent file = new DefaultStreamedContent(stream, "xml", "xml_" + utils.getFormattedCurrentDate() + "_" + busquedaBean.getAnoXml() + ".xml");
        return file;
    }

    private List<PRT.Registro.Clausula> getClausulas(String cad) {
        List<String> clausulas = Arrays.asList(cad.split(","));
        List<PRT.Registro.Clausula> out = new ArrayList<PRT.Registro.Clausula>(clausulas.size());

        for(String clausula : clausulas) {
            if(!clausula.equals("")) {
                PRT.Registro.Clausula c = new PRT.Registro.Clausula();
                c.setNumero(clausula.trim());
                out.add(c);
            }
        }
        return out;
    }

    private String getStringValue(Cell cell) {
        return cell.getStringCellValue();
    }

    private double getNumericValue(Cell cell) {
        return cell.getNumericCellValue();
    }

    public boolean isMostrarTabla() {
        return mostrarTabla;
    }

    public void setMostrarTabla(boolean mostrarTabla) {
        this.mostrarTabla = mostrarTabla;
    }

    public String getLineaDeNegocio() {
        return lineaDeNegocio;
    }

    public void setLineaDeNegocio(String lineaDeNegocio) {
        this.lineaDeNegocio = lineaDeNegocio;
    }

    public String getOrigen() {
        return origen;
    }

    public void setOrigen(String origen) {
        this.origen = origen;
    }

    public String getTipoDeDato() {
        return tipoDeDato;
    }

    public void setTipoDeDato(String tipoDeDato) {
        this.tipoDeDato = tipoDeDato;
    }

    public List<Circular2151> getListaDatos() {
        return listaDatos;
    }

    public void setListaDatos(List<Circular2151> listaDatos) {
        this.listaDatos = listaDatos;
    }

    public String getAnoPeriodo() {
        return anoPeriodo;
    }

    public void setAnoPeriodo(String anoPeriodo) {
        this.anoPeriodo = anoPeriodo;
    }

    public String getMesPeriodo() {
        return mesPeriodo;
    }

    public void setMesPeriodo(String mesPeriodo) {
        this.mesPeriodo = mesPeriodo;
    }

    public boolean isReadOnly() {
        return readOnly;
    }

    public void setReadOnly(boolean readOnly) {
        this.readOnly = readOnly;
    }

    public boolean isDesactivarBotonOtraBusqueda() {
        return desactivarBotonOtraBusqueda;
    }

    public void setDesactivarBotonOtraBusqueda(boolean desactivarBotonOtraBusqueda) {
        this.desactivarBotonOtraBusqueda = desactivarBotonOtraBusqueda;
    }

    public String getAnoXml() {
        return anoXml;
    }

    public void setAnoXml(String anoXml) {
        this.anoXml = anoXml;
    }

    public List<CirTabCir2151> getListaXmlPorPeriodo() {
        return listaXmlPorPeriodo;
    }

    public void setListaXmlPorPeriodo(List<CirTabCir2151> listaXmlPorPeriodo) {
        this.listaXmlPorPeriodo = listaXmlPorPeriodo;
    }

    public List<CirTabCir2151> getListaXmlDeExcel() {
        return listaXmlDeExcel;
    }

    public void setListaXmlDeExcel(List<CirTabCir2151> listaXmlDeExcel) {
        this.listaXmlDeExcel = listaXmlDeExcel;
    }

    public boolean isMostrarBotonExcelToXml() {
        return mostrarBotonExcelToXml;
    }

    public void setMostrarBotonExcelToXml(boolean mostrarBotonExcelToXml) {
        this.mostrarBotonExcelToXml = mostrarBotonExcelToXml;
    }

    public ArrayList<SelectItem> getListaTipoDato() {
        return listaTipoDato;
    }

    public void setListaTipoDato(ArrayList<SelectItem> listaTipoDato) {
        this.listaTipoDato = listaTipoDato;
    }

    public List<String> getLineasDeNegocio() {
        return lineasDeNegocio;
    }

    public void setLineasDeNegocio(List<String> lineasDeNegocio) {
        this.lineasDeNegocio = lineasDeNegocio;
    }

    public List<String> getOrigenes() {
        return origenes;
    }

    public void setOrigenes(List<String> origenes) {
        this.origenes = origenes;
    }
}

