package cl.metlife.circular2151.business.authentication;

import cl.metlife.circular2151.business.authentication.types.AuthenticationWsException;
import org.apache.log4j.Logger;

import javax.ejb.Singleton;
import javax.xml.rpc.ServiceException;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.util.Properties;

/**
 * Created by Blueprints on 2/19/2015.
 */
@Singleton
public class LoginManager {

    public LoginManager() {
    }

    private static final Logger logger = Logger.getLogger(LoginManager.class);
    /**
     *
     * @param username
     * @param password
     * @return
     * @throws InvalidUserNameException
     * @throws WrongPasswordException
     */
    public User login(String username, String password) throws InvalidUserNameException, WrongPasswordException, LoginException {

        /* pre-condiciones */
        if (username == null || username.trim().equals("")){
            throw new InvalidUserNameException("Nombre de usuario");
        }

        /* Se invoca el web-service */
        User user = null; // TODO: invocar ws.
        try {
            user = invokeLoginWebService(username, password);
        } catch (MalformedURLException e) {
            logger.error(e);
            throw new LoginException(e.getMessage(), e);
        }


        /* TODO: Here */
        return user;
    }

    private User invokeLoginWebService(String username, String password) throws WrongPasswordException, MalformedURLException {

        try {

            Properties prop = new Properties();

            InputStream input = new FileInputStream("config.properties");
            prop.load(input);

            AuthenticationManager authenticationManager = new AuthenticationManager(prop.getProperty("WsAutentificaEndpoint") + "?WSDL");
            RUT r = new RUT(15842225, '5');
            authenticationManager.isUserPasswordValid(r, password);

        } catch (ServiceException e) {
            logger.error(e);
        } catch (AuthenticationWsException e) {
            logger.error(e);
            throw new WrongPasswordException(e.getMessage());
        } catch(Exception e) {
            logger.error("No se pudo encontrar el archivo de configuración", e);
        }

        return new User();
    }
}
