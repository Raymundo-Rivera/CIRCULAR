/**
 * ServiceSoap_PortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package cl.metlife.circular2151.business.authentication.wsautentifica;

public interface ServiceSoap_PortType extends java.rmi.Remote {

    /**
     * [devuelve un xmldocument]
     */
    public Autentifica_InternoResponseAutentifica_InternoResult autentifica_Interno(String ID_Aplicacion, String login, String clave) throws java.rmi.RemoteException;

    /**
     * [devuelve un xmldocument]
     */
    public ROLES_PERSONA_RUT_APLICResponseROLES_PERSONA_RUT_APLICResult ROLES_PERSONA_RUT_APLIC(String ID_Aplicacion, String login) throws java.rmi.RemoteException;

    /**
     * [devuelve un String]
     */
    public LOGINResponseLOGINResult LOGIN(String vl_login, String clave) throws java.rmi.RemoteException;

    /**
     * [devuelve un String]
     */
    public Check_claveResponseCheck_claveResult check_clave(String inrut, String icclave, String icsession, String icidioma) throws java.rmi.RemoteException;

    /**
     * [Datos persona]
     */
    public Sp_info_personaResponseSp_info_personaResult sp_info_persona(String inrut) throws java.rmi.RemoteException;
}
