package cl.metlife.circular2151.beans;

import cl.metlife.circular2151.dao.CirTabExcelOriginDAO;
import cl.metlife.circular2151.dao.CircularDAO;
import cl.metlife.circular2151.entity.CirTabExcelOrigenCir2151;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.el.ELContext;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import java.io.Serializable;
import java.util.*;

/**
 * Created by Blueprints on 6/25/2015.
 */

@ManagedBean(name="archivosSubidosBean")
@ViewScoped
public class ArchivosSubidosBean extends BaseBean implements Serializable {

    private static final long serialVersionUID = 1L;
    private List<CirTabExcelOrigenCir2151> listaArchivosSubidos;

    @EJB
    public CirTabExcelOriginDAO excelOriginDAO;


    public List<CirTabExcelOrigenCir2151> getListaArchivosSubidos() {
        return excelOriginDAO.findAll();
    }

    public void setListaArchivosSubidos(List<CirTabExcelOrigenCir2151> listaArchivosSubidos) {
        this.listaArchivosSubidos = listaArchivosSubidos;
    }

    public void delete(CirTabExcelOrigenCir2151 dato){

        if(excelOriginDAO.delete(dato)){
            addMessage("Aviso", "Se elimino de forma correcta");
        } else {
            showError("Error", "Hubo un error al eliminar el registro");
        }

    }
}

