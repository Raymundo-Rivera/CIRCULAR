package cl.metlife.circular2151.business.authentication.types;

/**
 * Created by Ivan on 12-02-2015.
 */
public class AuthenticationWsException extends Exception {
    public AuthenticationWsException(String s) {
        super(s);
    }
}
