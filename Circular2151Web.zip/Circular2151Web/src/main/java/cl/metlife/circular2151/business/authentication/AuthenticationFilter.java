package cl.metlife.circular2151.business.authentication;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import cl.metlife.circular2151.beans.AuthenticationBean;
import cl.metlife.circular2151.business.authentication.types.Person;
import org.apache.log4j.*;

/**
 * Created by Blueprints on 8/19/2015.
 */
//@WebFilter(filterName = "AuthenticationFilter", urlPatterns = {"*.xhtml","*.jsf"})
public class AuthenticationFilter implements Filter {

    static private final Logger LOGGER = Logger.getLogger(AuthenticationFilter.class);

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;

        LOGGER.debug("friltrando URL:"+ req.getRequestURI());

        if (  req.getRequestURI().contains("Login.xhtml") || req.getRequestURI().contains("Error.xhtml") || hasPermission(req)) {
            chain.doFilter(request, response);
        } else if(!hasPermission(req))
        {
            res.sendRedirect(req.getContextPath() + "/views/Login.xhtml");
        }
        else
        {
            res.sendRedirect(req.getContextPath() + "/views/Login.xhtml");
        }

    }

    private boolean hasPermission(HttpServletRequest req) {

        Object value = req.getSession().getAttribute(AuthenticationBean.AUTH_KEY);
        LOGGER.trace("Filtrando autenticacion de usuario: {"+AuthenticationBean.AUTH_KEY+"} = {"+value+"} ");
        if(value == null)
            return false;


        AuthenticationBean auth = (AuthenticationBean) req.getSession().getAttribute("authenticationBean");

        Person u = auth.getLoggedUser();

        if(u == null)
            return false;

        return checkPermission(u,req.getRequestURI());

    }

    private boolean checkPermission(Person u, String requestURI) {

        LOGGER.trace("checkeando permisos de usuario {"+u.getUsername()+"} para url {"+requestURI+"}");

        if(u.getRoles().contains(AuthenticationManager.ADMIN_ROLE))
            return true;

        if(u.getRoles().contains(AuthenticationManager.USER_ROLE)){
            if(        requestURI.endsWith("/views/ArchivosSubidos.xhtml")
                    || requestURI.endsWith("/views/Busqueda.xhtml")
                    || requestURI.endsWith("/views/BusquedaPorPeriodo.xhtml")
                    || requestURI.endsWith("/views/RevisionConfirmaciones.xhtml")
                    )
                return true;
        }

        LOGGER.debug("ACCESS DENIED!!!!");

        return false;

    }

    @Override
    public void destroy() {
    }

    @Override
    public void init(FilterConfig arg0) throws ServletException {
    }

}
