package cl.metlife.servlet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import cl.metlife.circular2151.dao.CircularDAO;
import cl.metlife.circular2151.beans.PRT;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import javax.ejb.EJB;
import javax.servlet.ServletContext;
import java.io.*;

/**
 * Created by Ivan on 22-01-2015.
 */
public class exportExcel extends HttpServlet {

    private Workbook wb;
    private Sheet sheet;
    private final String EXCEL_FILENAME = "Ciruclar2151.xls";
    @EJB
    private CircularDAO circularDAO;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
            IOException {

        /* Getting payments conciliated or previously conciliated */
        String paymentsType = request.getParameter("t");

        PRT circular = circularDAO.getAllEntries();



        /* The format will be the Payments with Errors report format */

        wb = new HSSFWorkbook();
        sheet = wb.createSheet("Reporte Circular 2151");

        /* The header row */
        createHeaderRow();

        /* For every payment create a new Row */
        int row = 1;

        for(PRT.Registro reg : circular.getRegistro()) {
            createCircularRow(reg, row);
            ++row;
        }

        for(int i=0; i <= 8; i++) {
            sheet.autoSizeColumn(i);
        }

        //long concFileId = paymentsToExport.get(0).getConciliationFile().getId();

        String filePath = EXCEL_FILENAME;

        FileOutputStream fileOut = new FileOutputStream(filePath);
        wb.write(fileOut);
        fileOut.close();

        download(response, filePath);
    }

    private void createHeaderRow() {

        Row headerRow = sheet.createRow(0);

        /*Cell codigoUnicoCell = headerRow.createCell(0);
        codigoUnicoCell.setCellValue("Codigo Unico");*/

        Cell RUTCia = headerRow.createCell(1);
        RUTCia.setCellValue("RUT Cia");

        Cell GrupoCia = headerRow.createCell(2);
        GrupoCia.setCellValue("Grupo Cia");

        Cell Periodo = headerRow.createCell(3);
        Periodo.setCellValue("Periodo");

        Cell LineaDeNegocio = headerRow.createCell(4);
        LineaDeNegocio.setCellValue("Líneas de Negocio");

        Cell RamoEstadoFinanciero = headerRow.createCell(5);
        RamoEstadoFinanciero.setCellValue("Ramo Estado Financiero");

        Cell RamoCia = headerRow.createCell(6);
        RamoCia.setCellValue("Ramo Cia.");

        Cell NombreProd = headerRow.createCell(7);
        NombreProd.setCellValue("Nombre Producto");

        Cell Poliza = headerRow.createCell(8);
        Poliza.setCellValue("POL");

        Cell Clausulas = headerRow.createCell(9);
        Clausulas.setCellValue("CAD/CAL");

        Cell PrimaDirecta = headerRow.createCell(10);
        PrimaDirecta.setCellValue("Prima Directa M$");

        Cell FormaReserva = headerRow.createCell(11);
        FormaReserva.setCellValue("Forma de constitución de Reserva");

        Cell ReservaTecBruta = headerRow.createCell(12);
        ReservaTecBruta.setCellValue("Reserva Técnica Bruta M$");

        Cell ReservaTecNeta = headerRow.createCell(13);
        ReservaTecNeta.setCellValue("Reserva Técnica Neta M$");

        Cell PlazoSeguro = headerRow.createCell(14);
        PlazoSeguro.setCellValue("Plazo Seguro");


        Cell TablaMor = headerRow.createCell(15);
        TablaMor.setCellValue("Tabla mortalidad/morbilidad");






    }

    private void createCircularRow(PRT.Registro reg, int row) {

        Row dataRow = sheet.createRow(row);

        /* Payment Date */
       // Cell codigoUnicoCell = dataRow.createCell(0);
        Cell RUTCiaCell = dataRow.createCell(1);
        Cell GrupoCiaCell = dataRow.createCell(2);
        Cell PeriodoCell = dataRow.createCell(3);
        Cell LineaDeNegocioCell = dataRow.createCell(4);
        Cell RamoEstadoFinancieroCell = dataRow.createCell(5);
        Cell RamoCiaCell = dataRow.createCell(6);
        Cell NombreProdCell = dataRow.createCell(7);
        Cell PolizaCell = dataRow.createCell(8);
        Cell ClausulasCell = dataRow.createCell(9);
        Cell PrimaDirectaCell = dataRow.createCell(10);
        Cell FormaReservaCell = dataRow.createCell(11);
        Cell ReservaTecBrutaCell = dataRow.createCell(12);
        Cell ReservaTecNetaCell = dataRow.createCell(13);
        Cell PlazoSeguroCell = dataRow.createCell(14);
        Cell TablaMorCell = dataRow.createCell(15);

        //codigoUnicoCell.setCellValue(reg.getCodigoUnico());
        RUTCiaCell.setCellValue(reg.getRutCia());
        GrupoCiaCell.setCellValue(reg.getGrupoCia());
        PeriodoCell.setCellValue(reg.getPeriodo());
        LineaDeNegocioCell.setCellValue(reg.getLineasNegocio());
        RamoEstadoFinancieroCell.setCellValue(reg.getRamoEstFinanciero());
        RamoCiaCell.setCellValue(reg.getRamoCia());
        NombreProdCell.setCellValue(reg.getNombreProducto());
        PolizaCell.setCellValue(reg.getPoliza());
        PrimaDirectaCell.setCellValue(reg.getPrimaDirecta());
        FormaReservaCell.setCellValue(reg.getFormaReserva());
        ReservaTecBrutaCell.setCellValue(reg.getReservaTecnicaBruta());
        ReservaTecNetaCell.setCellValue(reg.getReservaTecnicaNeta());
        PlazoSeguroCell.setCellValue(reg.getPlazoSeguro());
        TablaMorCell.setCellValue(reg.getTablaMor());

        String clausulas = "";
        for(PRT.Registro.Clausula c : reg.getClausula()) {
            clausulas = clausulas + c.getNumero() + ",";
        }

        ClausulasCell.setCellValue(clausulas);

    }

    private void download(HttpServletResponse response, String filePath)
            throws IOException {

        /* Reads input file from an absolute path */
        File downloadFile = new File(filePath);
        FileInputStream inStream = new FileInputStream(downloadFile);

        ServletContext context = getServletContext();

        String mimeType = context.getMimeType(filePath);

        if (mimeType == null) {
            /* Set to binary type if MIME mapping not found */
            mimeType = "application/octet-stream";
        }
        System.out.println("MIME type: " + mimeType);

        response.setContentType(mimeType);
        response.setContentLength((int) downloadFile.length());

        /* Forces download */
        String headerKey = "Content-Disposition";
        String headerValue = String.format("attachment; filename=\"%s\"", downloadFile.getName());
        response.setHeader(headerKey, headerValue);

        /* Obtains response's output stream */
        OutputStream outStream = response.getOutputStream();

        byte[] buffer = new byte[4096];
        int bytesRead = -1;

        while ((bytesRead = inStream.read(buffer)) != -1) {
            outStream.write(buffer, 0, bytesRead);
        }

        inStream.close();
        outStream.close();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException,
            IOException {
        String paymentsToExportType = request.getParameter("t");

            doPost(request, response);

    }
}
