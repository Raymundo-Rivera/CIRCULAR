package cl.metlife.servlet;

import cl.blueprintsit.utils.XML;
import cl.metlife.circular2151.dao.CircularDAO;
import cl.metlife.circular2151.beans.PRT;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by Ivan on 15-01-2015.
 */

public class serializedToXml extends HttpServlet {

    @EJB
    private CircularDAO circularDAO;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        PRT circular = this.serializedToPrt((String)request.getAttribute("SerializedFile"));

        String xmlCircular = XML.marshall(circular);


        // You must tell the browser the file type you are going to send
        // for example application/pdf, text/plain, text/html, image/jpg
        response.setContentType("text/xml");

        // Make sure to show the download dialog
        response.setHeader("Content-disposition","attachment; filename=Circular2151.xml");

        response.getWriter().print(xmlCircular);
    }

    private PRT serializedToPrt(String serializedFile) {
        PRT circular = new PRT();
        List<PRT.Registro> registros = circular.getRegistro();

        List<String> lines = new ArrayList<String>(Arrays.asList(serializedFile.split("\n")));

        boolean first = true;
        int codUnico = 1;
        for( String line: lines) {
            if(first) {
                first = false;
            }
            else {
                line = "-1·#"+line;
                line = line.replaceAll("·#", " ·#");

                List<String> elements = new ArrayList<String>(Arrays.asList(line.split("·#")));

                PRT.Registro reg = new PRT.Registro();
                registros.add(reg);

                int eSize = elements.size();
                for(int i = eSize; i<=16; i++) {
                    elements.add("");
                }

                String RUTCia = elements.get(1).trim();
                String GrupoCia = elements.get(2).trim();
                String Periodo = elements.get(3).trim();
                String LineaDeNegocio = elements.get(4).trim();
                String RamoEstadoFinanciero = elements.get(5).trim();
                String RamoCia = elements.get(6).trim();
                String NombreProd = elements.get(7).trim();
                String Poliza = elements.get(8).trim();
                String Clausulas = elements.get(9).trim();
                String PrimaDirecta = elements.get(10).trim();
                String FormaReserva = elements.get(11).trim();
                String ReservaTecBruta = elements.get(12).trim();
                String ReservaTecNeta = elements.get(13).trim();
                String PlazoSeguro = elements.get(14).trim();
                String TablaMor = elements.get(15).trim();


                reg.setCodigoUnico(codUnico++);
                reg.setFormaReserva(FormaReserva);
                reg.setGrupoCia(Integer.parseInt(GrupoCia));
                reg.setLineasNegocio(LineaDeNegocio);
                reg.setNombreProducto(NombreProd);
                reg.setPeriodo(Integer.parseInt(Periodo));
                reg.setPlazoSeguro(PlazoSeguro);
                reg.setPoliza(Poliza);
                reg.setPrimaDirecta(Integer.parseInt(PrimaDirecta));
                reg.setRamoCia(RamoCia);
                reg.setRamoEstFinanciero(Integer.parseInt(RamoEstadoFinanciero));
                reg.setReservaTecnicaBruta(Long.parseLong(ReservaTecBruta));
                reg.setReservaTecnicaNeta(Long.parseLong(ReservaTecNeta));
                reg.setRutCia(RUTCia);
                reg.setTablaMor(TablaMor);

                List<PRT.Registro.Clausula> clausulasList = reg.getClausula();

                List<String> clStrings = new ArrayList<String>(Arrays.asList(Clausulas.split(",")));

                for(String cl : clStrings ) {
                    PRT.Registro.Clausula c = new PRT.Registro.Clausula();
                    c.setNumero(cl);
                    clausulasList.add(c);
                }




            }

        }

        return circular;
    }


    private void doGetBackup(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PRT circular = new PRT();

        List<PRT.Registro> registros = circular.getRegistro();
        PRT.Registro r1 = new PRT.Registro();
        r1.setCodigoUnico(1);
        r1.setFormaReserva("forma");
        r1.setGrupoCia(3/*BigInteger.valueOf(3)*/);
        r1.setLineasNegocio("lineas de negocio");
        r1.setNombreProducto("nombre prod");
        r1.setPeriodo(4/*BigInteger.valueOf(4)*/);
        r1.setPlazoSeguro("plazo");
        r1.setPoliza("poliza");
        r1.setPrimaDirecta(5);
        r1.setRamoCia("ramo cia");
        r1.setRamoEstFinanciero(6);
        r1.setReservaTecnicaBruta(7);
        r1.setReservaTecnicaNeta(8);
        r1.setRutCia("11111111");
        r1.setTablaMor("mor");
        List<PRT.Registro.Clausula> clausulas = r1.getClausula();
        PRT.Registro.Clausula c1 = new PRT.Registro.Clausula();
        PRT.Registro.Clausula c2 = new PRT.Registro.Clausula();

        c1.setNumero("123");
        c2.setNumero("312");

        clausulas.add(c1);
        clausulas.add(c2);
        registros.add(r1);

        String xmlCircular = XML.marshall(circular);

        response.getWriter().print(xmlCircular);


    }
}
