package cl.metlife.servlet;

import cl.blueprintsit.utils.XML;
import cl.metlife.circular2151.dao.CircularDAO;
import cl.metlife.circular2151.beans.PRT;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * Created by Ivan on 15-01-2015.
 */

public class XmlTest extends HttpServlet {

    @EJB
    private CircularDAO circularDAO;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        PRT circular = circularDAO.getAllEntries();

        String xmlCircular = XML.marshall(circular);

        response.getWriter().print(xmlCircular);
    }


    private void doGetBackup(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PRT circular = new PRT();

        List<PRT.Registro> registros = circular.getRegistro();
        PRT.Registro r1 = new PRT.Registro();
        r1.setCodigoUnico(1);
        r1.setFormaReserva("forma");
        r1.setGrupoCia(3/*BigInteger.valueOf(3)*/);
        r1.setLineasNegocio("lineas de negocio");
        r1.setNombreProducto("nombre prod");
        r1.setPeriodo(4/*BigInteger.valueOf(4)*/);
        r1.setPlazoSeguro("plazo");
        r1.setPoliza("poliza");
        r1.setPrimaDirecta(5);
        r1.setRamoCia("ramo cia");
        r1.setRamoEstFinanciero(6);
        r1.setReservaTecnicaBruta(7);
        r1.setReservaTecnicaNeta(8);
        r1.setRutCia("11111111");
        r1.setTablaMor("mor");
        List<PRT.Registro.Clausula> clausulas = r1.getClausula();
        PRT.Registro.Clausula c1 = new PRT.Registro.Clausula();
        PRT.Registro.Clausula c2 = new PRT.Registro.Clausula();

        c1.setNumero("123");
        c2.setNumero("312");

        clausulas.add(c1);
        clausulas.add(c2);
        registros.add(r1);

        String xmlCircular = XML.marshall(circular);

        response.getWriter().print(xmlCircular);


    }
}
