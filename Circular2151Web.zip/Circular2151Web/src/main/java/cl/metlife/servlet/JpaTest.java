package cl.metlife.servlet;

import cl.metlife.circular2151.dao.CircularDAO;
import cl.metlife.circular2151.beans.PRT;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * Created by Ivan on 15-01-2015.
 */

public class JpaTest extends HttpServlet {

    @EJB
    private CircularDAO circularDAO;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.getWriter().println("Prueba de JPA");
        //List<CirTabCir2151> datos = cirTabCirDato.getAllEntries();
        //List<String> descs = cirTabCirDato.getAllDescs();
        PRT prt = circularDAO.getAllEntries();
        List<PRT.Registro> registros = prt.getRegistro();

        for(PRT.Registro r: registros) {
            response.getWriter().println(r.getNombreProducto());

        }

    }
}
