package cl.metlife.servlet;

import cl.metlife.circular2151.dao.CircularDAO;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by Ivan on 16-01-2015.
 */
public class circData extends HttpServlet {
    private int PRETTY_PRINT_INDENT_FACTOR = 4;

    @EJB
    private CircularDAO circularDAO;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        /*String content = "{\"Result\":\"OK\",\n" +
                "\"Records\":[\n" +
                "{\"CodigoUnico\":88,\"RutCia\":2},\n" +
                "{\"CodigoUnico\":83,\"RutCia\":1}]\n" +
                ",\"TotalRecordCount\":2}";

        response.getWriter().println(content);*/
        response.getWriter().println(circularDAO.getCircularJson());


        /*PRT circular = cirTabCirDato.getAllEntries();

        String xmlCircular = XML.marshall(circular);


        try {
            JSONObject xmlJSONObj = XML.toJSONObject(xmlCircular);
            String jsonPrettyPrintString = xmlJSONObj.toString(PRETTY_PRINT_INDENT_FACTOR);
            response.getWriter().println(jsonPrettyPrintString);
        } catch (JSONException je) {
            System.out.println(je.toString());
        }*/

    }
}
