package cl.blueprintsit.utils;

public class DateUtils {

    public static String getBeautifulTime(long time) {

        long secondsNum = (time / 1000) % 60;
        long minutesNum = (time / (1000 * 60)) % 60;
        long hoursNum = (time / (1000 * 60 * 60)) % 24;

        /* Hours */
        String hours = "00";
        if( hoursNum < 10) {
            hours = "0"+hoursNum;
        }
        else {
            hours = ""+hoursNum;
        }

        /* Minutes */
        String minutes = "00";
        if( minutesNum < 10) {
            minutes = "0"+minutesNum;
        }
        else if( minutesNum >= 10 && minutesNum < 60) {
            minutes = ""+minutesNum;
        }

        /* Seconds */
        String seconds = "00";
        if( secondsNum < 10) {
            seconds = "0"+secondsNum;
        }
        else if( secondsNum >= 10 && secondsNum < 60) {
            seconds = ""+secondsNum;
        }

        return hours + ":" + minutes + ":" + seconds;

    }
}
