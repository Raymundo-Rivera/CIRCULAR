package cl.blueprintsit.utils;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.util.JAXBResult;
import javax.xml.transform.Result;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;

/**
 * Created by Ivan Pliouchtchai ivan@blueprintsit.cl on 15-01-2015.
 */
public class XML {
    public static String marshall(Object rootElement) {

        JAXBContext jaxbContext = null;

        try {
            jaxbContext = JAXBContext.newInstance(rootElement.getClass());
            Marshaller jaxbMarshaller = jaxbContext.createMarshaller();


            // output pretty printed
            jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

            ByteArrayOutputStream os = new ByteArrayOutputStream();
            jaxbMarshaller.marshal(rootElement, os);
            String result = new String(os.toByteArray(), "UTF-8");
            //String result = new String(os.toByteArray(), "ISO-8859-1");



            return result;
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (JAXBException e) {
            e.printStackTrace();
        }

        return "";
    }

}
