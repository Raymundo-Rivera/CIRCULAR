package cl.blueprintsit.utils.files;

public class NotADirectoryException extends Throwable {

	private static final long serialVersionUID = -4701162668408634075L;
}
