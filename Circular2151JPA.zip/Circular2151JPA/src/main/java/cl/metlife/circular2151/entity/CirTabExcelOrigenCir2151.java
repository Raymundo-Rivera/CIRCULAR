package cl.metlife.circular2151.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the CIR_TAB_EXCEL_ORIGEN_CIR2151 database table.
 * 
 */
@Entity
@Table(name="CIR_TAB_EXCEL_ORIGEN_CIR2151")
@NamedQuery(name="CirTabExcelOrigenCir2151.findAll", query="SELECT c FROM CirTabExcelOrigenCir2151 c")
public class CirTabExcelOrigenCir2151 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="CIR_TAB_EXCEL_ORIGEN_CIR2151")
	private Long cirTabExcelOrigenCir2151;

	@Column(name="NOMBRE_ARCHIVO")
	private String nombreArchivo;

	@Temporal(TemporalType.TIMESTAMP)
	private Date subido;

	private String usuario;

	//bi-directional many-to-one association to CirTabSab2151
	@OneToMany(mappedBy="cirTabExcelOrigenCir2151")
	private List<CirTabSab2151> cirTabSab2151s;

	public CirTabExcelOrigenCir2151() {
	}

	public Long getCirTabExcelOrigenCir2151() {
		return this.cirTabExcelOrigenCir2151;
	}

	public void setCirTabExcelOrigenCir2151(Long cirTabExcelOrigenCir2151) {
		this.cirTabExcelOrigenCir2151 = cirTabExcelOrigenCir2151;
	}

	public String getNombreArchivo() {
		return this.nombreArchivo;
	}

	public void setNombreArchivo(String nombreArchivo) {
		this.nombreArchivo = nombreArchivo;
	}

	public Date getSubido() {
		return this.subido;
	}

	public void setSubido(Date subido) {
		this.subido = subido;
	}

	public String getUsuario() {
		return this.usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public List<CirTabSab2151> getCirTabSab2151s() {
		return this.cirTabSab2151s;
	}

	public void setCirTabSab2151s(List<CirTabSab2151> cirTabSab2151s) {
		this.cirTabSab2151s = cirTabSab2151s;
	}

	public CirTabSab2151 addCirTabSab2151(CirTabSab2151 cirTabSab2151) {
		getCirTabSab2151s().add(cirTabSab2151);
		cirTabSab2151.setCirTabExcelOrigenCir2151(this);

		return cirTabSab2151;
	}

	public CirTabSab2151 removeCirTabSab2151(CirTabSab2151 cirTabSab2151) {
		getCirTabSab2151s().remove(cirTabSab2151);
		cirTabSab2151.setCirTabExcelOrigenCir2151(null);

		return cirTabSab2151;
	}

}