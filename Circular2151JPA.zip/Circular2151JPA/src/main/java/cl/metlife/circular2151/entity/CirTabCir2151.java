package cl.metlife.circular2151.entity;

import javax.persistence.*;
import java.io.Serializable;


/**
 * The persistent class for the CIR_TAB_CIR2151 database table.
 * 
 */
@Entity
@Table(name="CIR_TAB_CIR2151")
@NamedQuery(name="CirTabCir2151.findAll", query="SELECT c FROM CirTabCir2151 c")
public class CirTabCir2151 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="CIR_TAB_CIR2151_ID")
	private long cirTabCir2151Id;

	private String base;

	@Column(name="CIRC_COD_FORMA_RES")
	private String circCodFormaRes;

	@Column(name="CIRC_PLAZO_SEGURO")
	private String circPlazoSeguro;

	@Column(name="CIRC_TABLA_MORTALIDAD")
	private String circTablaMortalidad;

	private String cod;

	@Column(name="DESC_PROD")
	private String descProd;

	private String enviado;

	private int grupo;

	@Column(name="LINEA_DE_NEGOCIOS")
	private String lineaDeNegocios;

	private String origen;

	private String periodo;

	private String pol;

	private double prima;

	@Column(name="RAMO_CIA")
	private String ramoCia;

	@Column(name="RAMO_ESTADO_FINAN")
	private int ramoEstadoFinan;

	@Column(name="RESERVA_BRUTA")
	private double reservaBruta;

	@Column(name="RESERVA_NETA")
	private double reservaNeta;

	@Column(name="RUT_CIA")
	private String rutCia;

	public CirTabCir2151() {
	}

	public long getCirTabCir2151Id() {
		return this.cirTabCir2151Id;
	}

	public void setCirTabCir2151Id(long cirTabCir2151Id) {
		this.cirTabCir2151Id = cirTabCir2151Id;
	}

	public String getBase() {
		return this.base;
	}

	public void setBase(String base) {
		this.base = base;
	}

	public String getCircCodFormaRes() {
		return this.circCodFormaRes;
	}

	public void setCircCodFormaRes(String circCodFormaRes) {
		this.circCodFormaRes = circCodFormaRes;
	}

	public String getCircPlazoSeguro() {
		return this.circPlazoSeguro;
	}

	public void setCircPlazoSeguro(String circPlazoSeguro) {
		this.circPlazoSeguro = circPlazoSeguro;
	}

	public String getCircTablaMortalidad() {
		return this.circTablaMortalidad;
	}

	public void setCircTablaMortalidad(String circTablaMortalidad) {
		this.circTablaMortalidad = circTablaMortalidad;
	}

	public String getCod() {
		return this.cod;
	}

	public void setCod(String cod) {
		this.cod = cod;
	}

	public String getDescProd() {
		return this.descProd;
	}

	public void setDescProd(String descProd) {
		this.descProd = descProd;
	}

	public String getEnviado() {
		return this.enviado;
	}

	public void setEnviado(String enviado) {
		this.enviado = enviado;
	}

	public int getGrupo() {
		return this.grupo;
	}

	public void setGrupo(int grupo) {
		this.grupo = grupo;
	}

	public String getLineaDeNegocios() {
		return this.lineaDeNegocios;
	}

	public void setLineaDeNegocios(String lineaDeNegocios) {
		this.lineaDeNegocios = lineaDeNegocios;
	}

	public String getOrigen() {
		return this.origen;
	}

	public void setOrigen(String origen) {
		this.origen = origen;
	}

	public String getPeriodo() {
		return this.periodo;
	}

	public void setPeriodo(String periodo) {
		this.periodo = periodo;
	}

	public String getPol() {
		return this.pol;
	}

	public void setPol(String pol) {
		this.pol = pol;
	}

	public double getPrima() {
		return this.prima;
	}

	public void setPrima(double prima) {
		this.prima = prima;
	}

	public String getRamoCia() {
		return this.ramoCia;
	}

	public void setRamoCia(String ramoCia) {
		this.ramoCia = ramoCia;
	}

	public int getRamoEstadoFinan() {
		return this.ramoEstadoFinan;
	}

	public void setRamoEstadoFinan(int ramoEstadoFinan) {
		this.ramoEstadoFinan = ramoEstadoFinan;
	}

	public double getReservaBruta() {
		return this.reservaBruta;
	}

	public void setReservaBruta(double reservaBruta) {
		this.reservaBruta = reservaBruta;
	}

	public double getReservaNeta() {
		return this.reservaNeta;
	}

	public void setReservaNeta(double reservaNeta) {
		this.reservaNeta = reservaNeta;
	}

	public String getRutCia() {
		return this.rutCia;
	}

	public void setRutCia(String rutCia) {
		this.rutCia = rutCia;
	}

}