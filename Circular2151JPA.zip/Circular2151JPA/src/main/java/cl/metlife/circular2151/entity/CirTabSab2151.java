package cl.metlife.circular2151.entity;

import javax.persistence.*;
import java.io.Serializable;


/**
 * The persistent class for the CIR_TAB_SAB2151 database table.
 * 
 */
@Entity
@Table(name="CIR_TAB_SAB2151")
public class CirTabSab2151 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="CIR_TAB_SAB2151_ID")
	private Long cirTabSab2151Id;

	private String aprobado;

	private String base;

	private String canalventa;

	@Column(name="COD_CAD")
	private String codCad;

	@Column(name="COD_COBE")
	private String codCobe;

	@Column(name="COD_FECU")
	private String codFecu;

	@Column(name="COD_FORMA_RES")
	private String codFormaRes;

	@Column(name="COD_LOB")
	private String codLob;

	@Column(name="COD_POL")
	private String codPol;

	@Column(name="COD_PROD")
	private String codProd;

	@Column(name="DSC_PROD")
	private String dscProd;

	@Column(name="GRP_CIA")
	private String grpCia;

    @Column(name="LINEA")
	private String linea;

	@Column(name="LINEA_NEGOCIO")
	private String lineaNegocio;

    @Column(name="ORIGEN")
	private String origen;

    @Column(name="PERIODO")
	private String periodo;

	@Column(name="PLAZO_SEGURO")
	private String plazoSeguro;

	private String poliza;

	@Column(name="PORC_CEDIDO")
	private double porcCedido;

	private double prima;

	@Column(name="PRIMA_PS")
	private Long primaPs;

	private double reserva;

	@Column(name="RESERVA_BRUTA_PS")
	private double reservaBrutaPs;

	@Column(name="RESERVA_NETA")
	private double reservaNeta;

	@Column(name="RESERVAS_NETA_PS")
	private double reservasNetaPs;

	@Column(name="RUT_CIA")
	private String rutCia;

	@Column(name="TABLA_MORTALIDAD")
	private String tablaMortalidad;

	@Column(name="TIPO_DATO")
	private String tipoDato;

	@Column(name="USUARIO_APRUEBA")
	private String usuarioAprueba;

	//bi-directional many-to-one association to CirTabExcelOrigenCir2151
	@ManyToOne
	@JoinColumn(name="EXCEL_ORIGEN")
	private CirTabExcelOrigenCir2151 cirTabExcelOrigenCir2151;

	public CirTabSab2151() {
	}

	public Long getCirTabSab2151Id() {
		return this.cirTabSab2151Id;
	}

	public void setCirTabSab2151Id(Long cirTabSab2151Id) {
		this.cirTabSab2151Id = cirTabSab2151Id;
	}

	public String getAprobado() {
		return this.aprobado;
	}

	public void setAprobado(String aprobado) {
		this.aprobado = aprobado;
	}

	public String getBase() {
		return this.base;
	}

	public void setBase(String base) {
		this.base = base;
	}

	public String getCanalventa() {
		return this.canalventa;
	}

	public void setCanalventa(String canalventa) {
		this.canalventa = canalventa;
	}

	public String getCodCad() {
		return this.codCad;
	}

	public void setCodCad(String codCad) {
		this.codCad = codCad;
	}

	public String getCodCobe() {
		return this.codCobe;
	}

	public void setCodCobe(String codCobe) {
		this.codCobe = codCobe;
	}

	public String getCodFecu() {
		return this.codFecu;
	}

	public void setCodFecu(String codFecu) {
		this.codFecu = codFecu;
	}

	public String getCodFormaRes() {
		return this.codFormaRes;
	}

	public void setCodFormaRes(String codFormaRes) {
		this.codFormaRes = codFormaRes;
	}

	public String getCodLob() {
		return this.codLob;
	}

	public void setCodLob(String codLob) {
		this.codLob = codLob;
	}

	public String getCodPol() {
		return this.codPol;
	}

	public void setCodPol(String codPol) {
		this.codPol = codPol;
	}

	public String getCodProd() {
		return this.codProd;
	}

	public void setCodProd(String codProd) {
		this.codProd = codProd;
	}

	public String getDscProd() {
		return this.dscProd;
	}

	public void setDscProd(String dscProd) {
		this.dscProd = dscProd;
	}

	public String getGrpCia() {
		return this.grpCia;
	}

	public void setGrpCia(String grpCia) {
		this.grpCia = grpCia;
	}

	public String getLinea() {
		return this.linea;
	}

	public void setLinea(String linea) {
		this.linea = linea;
	}

	public String getLineaNegocio() {
		return this.lineaNegocio;
	}

	public void setLineaNegocio(String lineaNegocio) {
		this.lineaNegocio = lineaNegocio;
	}

	public String getOrigen() {
		return this.origen;
	}

	public void setOrigen(String origen) {
		this.origen = origen;
	}

	public String getPeriodo() {
		return this.periodo;
	}

	public void setPeriodo(String periodo) {
		this.periodo = periodo;
	}

	public String getPlazoSeguro() {
		return this.plazoSeguro;
	}

	public void setPlazoSeguro(String plazoSeguro) {
		this.plazoSeguro = plazoSeguro;
	}

	public String getPoliza() {
		return this.poliza;
	}

	public void setPoliza(String poliza) {
		this.poliza = poliza;
	}

	public double getPorcCedido() {
		return this.porcCedido;
	}

	public void setPorcCedido(double porcCedido) {
		this.porcCedido = porcCedido;
	}

	public double getPrima() {
		return this.prima;
	}

	public void setPrima(double prima) {
		this.prima = prima;
	}

	public Long getPrimaPs() {
		return this.primaPs;
	}

	public void setPrimaPs(Long primaPs) {
		this.primaPs = primaPs;
	}

	public double getReserva() {
		return this.reserva;
	}

	public void setReserva(double reserva) {
		this.reserva = reserva;
	}

	public double getReservaBrutaPs() {
		return this.reservaBrutaPs;
	}

	public void setReservaBrutaPs(double reservaBrutaPs) {
		this.reservaBrutaPs = reservaBrutaPs;
	}

	public double getReservaNeta() {
		return this.reservaNeta;
	}

	public void setReservaNeta(double reservaNeta) {
		this.reservaNeta = reservaNeta;
	}

	public double getReservasNetaPs() {
		return this.reservasNetaPs;
	}

	public void setReservasNetaPs(double reservasNetaPs) {
		this.reservasNetaPs = reservasNetaPs;
	}

	public String getRutCia() {
		return this.rutCia;
	}

	public void setRutCia(String rutCia) {
		this.rutCia = rutCia;
	}

	public String getTablaMortalidad() {
		return this.tablaMortalidad;
	}

	public void setTablaMortalidad(String tablaMortalidad) {
		this.tablaMortalidad = tablaMortalidad;
	}

	public String getTipoDato() {
		return this.tipoDato;
	}

	public void setTipoDato(String tipoDato) {
		this.tipoDato = tipoDato;
	}

	public String getUsuarioAprueba() {
		return this.usuarioAprueba;
	}

	public void setUsuarioAprueba(String usuarioAprueba) {
		this.usuarioAprueba = usuarioAprueba;
	}

	public CirTabExcelOrigenCir2151 getCirTabExcelOrigenCir2151() {
		return this.cirTabExcelOrigenCir2151;
	}

	public void setCirTabExcelOrigenCir2151(CirTabExcelOrigenCir2151 cirTabExcelOrigenCir2151) {
		this.cirTabExcelOrigenCir2151 = cirTabExcelOrigenCir2151;
	}

}