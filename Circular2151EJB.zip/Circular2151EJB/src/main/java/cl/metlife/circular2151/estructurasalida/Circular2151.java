package cl.metlife.circular2151.estructurasalida;

import java.io.Serializable;

/**
 * Created by Blueprints on 7/30/2015.
 */
public class Circular2151 implements Serializable {

    private String rut;
    private String canal_venta;
    private String poliza;
    private String cod_prod;
    private String dsc_prod;
    private String cod_fecu;
    private String cod_pol;
    private String cod_cad;
    private Double prima_uf;
    private Double prima_pesos;
    private boolean confirmed;

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getCanal_venta() {
        return canal_venta;
    }

    public void setCanal_venta(String canal_venta) {
        this.canal_venta = canal_venta;
    }

    public String getPoliza() {
        return poliza;
    }

    public void setPoliza(String poliza) {
        this.poliza = poliza;
    }

    public String getCod_prod() {
        return cod_prod;
    }

    public void setCod_prod(String cod_prod) {
        this.cod_prod = cod_prod;
    }

    public String getDsc_prod() {
        return dsc_prod;
    }

    public void setDsc_prod(String dsc_prod) {
        this.dsc_prod = dsc_prod;
    }

    public String getCod_fecu() {
        return cod_fecu;
    }

    public void setCod_fecu(String cod_fecu) {
        this.cod_fecu = cod_fecu;
    }

    public String getCod_pol() {
        return cod_pol;
    }

    public void setCod_pol(String cod_pol) {
        this.cod_pol = cod_pol;
    }

    public String getCod_cad() {
        return cod_cad;
    }

    public void setCod_cad(String cod_cad) {
        this.cod_cad = cod_cad;
    }

    public Double getPrima_uf() {
        return prima_uf;
    }

    public void setPrima_uf(Double prima_uf) {
        this.prima_uf = prima_uf;
    }

    public Double getPrima_pesos() {
        return prima_pesos;
    }

    public void setPrima_pesos(Double prima_pesos) {
        this.prima_pesos = prima_pesos;
    }

    public boolean isConfirmed() {
        return confirmed;
    }

    public void setConfirmed(boolean confirmed) {
        this.confirmed = confirmed;
    }
}
