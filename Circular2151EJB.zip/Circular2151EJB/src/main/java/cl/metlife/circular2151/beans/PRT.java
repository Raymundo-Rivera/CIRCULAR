
package cl.metlife.circular2151.beans;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence maxOccurs="unbounded">
 *         &lt;element name="Registro">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="CodigoUnico">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}positiveInteger">
 *                         &lt;minInclusive value="1"/>
 *                         &lt;maxInclusive value="999999"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="RutCia">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}positiveInteger">
 *                         &lt;minInclusive value="99999"/>
 *                         &lt;maxInclusive value="999999999"/>
 *                         &lt;totalDigits value="9"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="GrupoCia">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}integer">
 *                         &lt;enumeration value="1"/>
 *                         &lt;enumeration value="2"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="Periodo">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}positiveInteger">
 *                         &lt;totalDigits value="4"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="LineasNegocio">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;minLength value="0"/>
 *                         &lt;maxLength value="3"/>
 *                         &lt;enumeration value="I"/>
 *                         &lt;enumeration value="C"/>
 *                         &lt;enumeration value="MH"/>
 *                         &lt;enumeration value="MC"/>
 *                         &lt;enumeration value="MO"/>
 *                         &lt;enumeration value="IIC"/>
 *                         &lt;enumeration value="BR"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="RamoEstFinanciero">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}integer">
 *                         &lt;minInclusive value="1"/>
 *                         &lt;maxInclusive value="426"/>
 *                         &lt;totalDigits value="3"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="RamoCia">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;minLength value="0"/>
 *                         &lt;maxLength value="20"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="NombreProducto">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;minLength value="0"/>
 *                         &lt;maxLength value="500"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="Poliza">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;minLength value="0"/>
 *                         &lt;maxLength value="14"/>
 *                         &lt;pattern value="(POL|pol).[0-9]*"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="Clausula" maxOccurs="unbounded">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="Numero">
 *                               &lt;simpleType>
 *                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                                   &lt;minLength value="0"/>
 *                                   &lt;maxLength value="14"/>
 *                                   &lt;pattern value="(CAD|cad|CAL|cal|COP|cop|CUG|cug).[0-9]*"/>
 *                                 &lt;/restriction>
 *                               &lt;/simpleType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="PrimaDirecta">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}integer">
 *                         &lt;minInclusive value="0"/>
 *                         &lt;maxInclusive value="99999999999"/>
 *                         &lt;totalDigits value="11"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="FormaReserva">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;minLength value="0"/>
 *                         &lt;maxLength value="11"/>
 *                         &lt;enumeration value="RRC-306"/>
 *                         &lt;enumeration value="RM-306"/>
 *                         &lt;enumeration value="RRC-MP(1)"/>
 *                         &lt;enumeration value="RM-MP(1)"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="ReservaTecnicaBruta">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}integer">
 *                         &lt;minInclusive value="0"/>
 *                         &lt;maxInclusive value="99999999999"/>
 *                         &lt;totalDigits value="11"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="ReservaTecnicaNeta">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}integer">
 *                         &lt;minInclusive value="0"/>
 *                         &lt;maxInclusive value="99999999999"/>
 *                         &lt;totalDigits value="11"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="PlazoSeguro">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;minLength value="0"/>
 *                         &lt;maxLength value="7"/>
 *                         &lt;enumeration value="C/P-306"/>
 *                         &lt;enumeration value="C/P-CP"/>
 *                         &lt;enumeration value="L/P"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="TablaMor">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;minLength value="0"/>
 *                         &lt;maxLength value="50"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "registro"
})
@XmlRootElement(name = "PRT")
public class PRT {

    @XmlElement(name = "Registro", required = true)
    protected List<PRT.Registro> registro;

    /**
     * Gets the value of the registro property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the registro property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRegistro().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PRT.Registro }
     * 
     * 
     */
    public List<PRT.Registro> getRegistro() {
        if (registro == null) {
            registro = new ArrayList<PRT.Registro>();
        }
        return this.registro;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="CodigoUnico">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}positiveInteger">
     *               &lt;minInclusive value="1"/>
     *               &lt;maxInclusive value="999999"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="RutCia">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}positiveInteger">
     *               &lt;minInclusive value="99999"/>
     *               &lt;maxInclusive value="999999999"/>
     *               &lt;totalDigits value="9"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="GrupoCia">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}integer">
     *               &lt;enumeration value="1"/>
     *               &lt;enumeration value="2"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="Periodo">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}positiveInteger">
     *               &lt;totalDigits value="4"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="LineasNegocio">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;minLength value="0"/>
     *               &lt;maxLength value="3"/>
     *               &lt;enumeration value="I"/>
     *               &lt;enumeration value="C"/>
     *               &lt;enumeration value="MH"/>
     *               &lt;enumeration value="MC"/>
     *               &lt;enumeration value="MO"/>
     *               &lt;enumeration value="IIC"/>
     *               &lt;enumeration value="BR"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="RamoEstFinanciero">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}integer">
     *               &lt;minInclusive value="1"/>
     *               &lt;maxInclusive value="426"/>
     *               &lt;totalDigits value="3"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="RamoCia">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;minLength value="0"/>
     *               &lt;maxLength value="20"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="NombreProducto">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;minLength value="0"/>
     *               &lt;maxLength value="500"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="Poliza">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;minLength value="0"/>
     *               &lt;maxLength value="14"/>
     *               &lt;pattern value="(POL|pol).[0-9]*"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="Clausula" maxOccurs="unbounded">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="Numero">
     *                     &lt;simpleType>
     *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *                         &lt;minLength value="0"/>
     *                         &lt;maxLength value="14"/>
     *                         &lt;pattern value="(CAD|cad|CAL|cal|COP|cop|CUG|cug).[0-9]*"/>
     *                       &lt;/restriction>
     *                     &lt;/simpleType>
     *                   &lt;/element>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="PrimaDirecta">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}integer">
     *               &lt;minInclusive value="0"/>
     *               &lt;maxInclusive value="99999999999"/>
     *               &lt;totalDigits value="11"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="FormaReserva">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;minLength value="0"/>
     *               &lt;maxLength value="11"/>
     *               &lt;enumeration value="RRC-306"/>
     *               &lt;enumeration value="RM-306"/>
     *               &lt;enumeration value="RRC-MP(1)"/>
     *               &lt;enumeration value="RM-MP(1)"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="ReservaTecnicaBruta">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}integer">
     *               &lt;minInclusive value="0"/>
     *               &lt;maxInclusive value="99999999999"/>
     *               &lt;totalDigits value="11"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="ReservaTecnicaNeta">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}integer">
     *               &lt;minInclusive value="0"/>
     *               &lt;maxInclusive value="99999999999"/>
     *               &lt;totalDigits value="11"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="PlazoSeguro">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;minLength value="0"/>
     *               &lt;maxLength value="7"/>
     *               &lt;enumeration value="C/P-306"/>
     *               &lt;enumeration value="C/P-CP"/>
     *               &lt;enumeration value="L/P"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="TablaMor">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;minLength value="0"/>
     *               &lt;maxLength value="50"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "codigoUnico",
        "rutCia",
        "grupoCia",
        "periodo",
        "lineasNegocio",
        "ramoEstFinanciero",
        "ramoCia",
        "nombreProducto",
        "poliza",
        "clausula",
        "primaDirecta",
        "formaReserva",
        "reservaTecnicaBruta",
        "reservaTecnicaNeta",
        "plazoSeguro",
        "tablaMor"
    })
    public static class Registro {

        @XmlElement(name = "CodigoUnico")
        protected int codigoUnico;
        @XmlElement(name = "RutCia")
        protected String rutCia;
        @XmlElement(name = "GrupoCia", required = true)
        protected int grupoCia;
        @XmlElement(name = "Periodo", required = true)
        protected int periodo;
        @XmlElement(name = "LineasNegocio", required = true)
        protected String lineasNegocio;
        @XmlElement(name = "RamoEstFinanciero")
        protected int ramoEstFinanciero;
        @XmlElement(name = "RamoCia", required = true)
        protected String ramoCia;
        @XmlElement(name = "NombreProducto", required = true)
        protected String nombreProducto;
        @XmlElement(name = "Poliza", required = true)
        protected String poliza;
        @XmlElement(name = "Clausula", required = true)
        protected List<PRT.Registro.Clausula> clausula;
        @XmlElement(name = "PrimaDirecta")
        protected long primaDirecta;
        @XmlElement(name = "FormaReserva", required = true)
        protected String formaReserva;
        @XmlElement(name = "ReservaTecnicaBruta")
        protected long reservaTecnicaBruta;
        @XmlElement(name = "ReservaTecnicaNeta")
        protected long reservaTecnicaNeta;
        @XmlElement(name = "PlazoSeguro", required = true)
        protected String plazoSeguro;
        @XmlElement(name = "TablaMor", required = true)
        protected String tablaMor;

        /**
         * Gets the value of the codigoUnico property.
         * 
         */
        public int getCodigoUnico() {
            return codigoUnico;
        }

        /**
         * Sets the value of the codigoUnico property.
         * 
         */
        public void setCodigoUnico(int value) {
            this.codigoUnico = value;
        }

        /**
         * Gets the value of the rutCia property.
         * 
         */
        public String getRutCia() {
            return rutCia;
        }

        /**
         * Sets the value of the rutCia property.
         * 
         */
        public void setRutCia(String value) {
            this.rutCia = value;
        }

        /**
         * Gets the value of the grupoCia property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public int getGrupoCia() {
            return grupoCia;
        }

        /**
         * Sets the value of the grupoCia property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setGrupoCia(int value) {
            this.grupoCia = value;
        }

        /**
         * Gets the value of the periodo property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public int getPeriodo() {
            return periodo;
        }

        /**
         * Sets the value of the periodo property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setPeriodo(int value) {
            this.periodo = value;
        }

        /**
         * Gets the value of the lineasNegocio property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getLineasNegocio() {
            return lineasNegocio;
        }

        /**
         * Sets the value of the lineasNegocio property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setLineasNegocio(String value) {
            this.lineasNegocio = value;
        }

        /**
         * Gets the value of the ramoEstFinanciero property.
         * 
         */
        public int getRamoEstFinanciero() {
            return ramoEstFinanciero;
        }

        /**
         * Sets the value of the ramoEstFinanciero property.
         *
         * @param value
         */
        public void setRamoEstFinanciero(int value) {
            this.ramoEstFinanciero = value;
        }

        /**
         * Gets the value of the ramoCia property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getRamoCia() {
            return ramoCia;
        }

        /**
         * Sets the value of the ramoCia property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setRamoCia(String value) {
            this.ramoCia = value;
        }

        /**
         * Gets the value of the nombreProducto property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getNombreProducto() {
            return nombreProducto;
        }

        /**
         * Sets the value of the nombreProducto property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setNombreProducto(String value) {
            this.nombreProducto = value;
        }

        /**
         * Gets the value of the poliza property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getPoliza() {
            return poliza;
        }

        /**
         * Sets the value of the poliza property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setPoliza(String value) {
            this.poliza = value;
        }

        /**
         * Gets the value of the clausula property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the clausula property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getClausula().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link PRT.Registro.Clausula }
         * 
         * 
         */
        public List<PRT.Registro.Clausula> getClausula() {
            if (clausula == null) {
                clausula = new ArrayList<PRT.Registro.Clausula>();
            }
            return this.clausula;
        }

        public void setClausula(List<Clausula> clausula) {
            this.clausula = clausula;
        }

        /**
         * Gets the value of the primaDirecta property.
         * 
         */
        public long getPrimaDirecta() {
            return primaDirecta;
        }

        /**
         * Sets the value of the primaDirecta property.
         * 
         */
        public void setPrimaDirecta(long value) {
            this.primaDirecta = value;
        }

        /**
         * Gets the value of the formaReserva property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getFormaReserva() {
            return formaReserva;
        }

        /**
         * Sets the value of the formaReserva property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setFormaReserva(String value) {
            this.formaReserva = value;
        }

        /**
         * Gets the value of the reservaTecnicaBruta property.
         * 
         */
        public long getReservaTecnicaBruta() {
            return reservaTecnicaBruta;
        }

        /**
         * Sets the value of the reservaTecnicaBruta property.
         * 
         */
        public void setReservaTecnicaBruta(long value) {
            this.reservaTecnicaBruta = value;
        }

        /**
         * Gets the value of the reservaTecnicaNeta property.
         * 
         */
        public long getReservaTecnicaNeta() {
            return reservaTecnicaNeta;
        }

        /**
         * Sets the value of the reservaTecnicaNeta property.
         * 
         */
        public void setReservaTecnicaNeta(long value) {
            this.reservaTecnicaNeta = value;
        }

        /**
         * Gets the value of the plazoSeguro property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getPlazoSeguro() {
            return plazoSeguro;
        }

        /**
         * Sets the value of the plazoSeguro property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setPlazoSeguro(String value) {
            this.plazoSeguro = value;
        }

        /**
         * Gets the value of the tablaMor property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getTablaMor() {
            return tablaMor;
        }

        /**
         * Sets the value of the tablaMor property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setTablaMor(String value) {
            this.tablaMor = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="Numero">
         *           &lt;simpleType>
         *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
         *               &lt;minLength value="0"/>
         *               &lt;maxLength value="14"/>
         *               &lt;pattern value="(CAD|cad|CAL|cal|COP|cop|CUG|cug).[0-9]*"/>
         *             &lt;/restriction>
         *           &lt;/simpleType>
         *         &lt;/element>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "numero"
        })
        public static class Clausula {

            @XmlElement(name = "Numero", required = true)
            protected String numero;

            /**
             * Gets the value of the numero property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getNumero() {
                return numero;
            }

            /**
             * Sets the value of the numero property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setNumero(String value) {
                this.numero = value;
            }

        }

    }

}
