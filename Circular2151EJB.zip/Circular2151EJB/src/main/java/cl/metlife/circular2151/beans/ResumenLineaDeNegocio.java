package cl.metlife.circular2151.beans;

import java.io.Serializable;

/**
 * Created by Blueprints on 8/4/2015.
 */
public class ResumenLineaDeNegocio implements Serializable {

    private String linea;
    private Long aprobados;
    private Long noAprobados;
    private Long marcados;
    private Long total;

    public String getLinea() {
        return linea;
    }

    public void setLinea(String linea) {
        this.linea = linea;
    }

    public Long getAprobados() {
        return aprobados;
    }

    public void setAprobados(Long aprobados) {
        this.aprobados = aprobados;
    }

    public Long getNoAprobados() {
        return noAprobados;
    }

    public void setNoAprobados(Long noAprobados) {
        this.noAprobados = noAprobados;
    }

    public Long getMarcados() {
        return marcados;
    }

    public void setMarcados(Long marcados) {
        this.marcados = marcados;
    }

    public Long getTotal() {
        return total;
    }

    public void setTotal(Long total) {
        this.total = total;
    }
}
