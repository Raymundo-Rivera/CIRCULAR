package cl.metlife.circular2151.dao;


import cl.metlife.circular2151.beans.ResumenLineaDeNegocio;
import cl.metlife.circular2151.entity.CirTabExcelOrigenCir2151;
import cl.metlife.circular2151.entity.CirTabSab2151;
import cl.metlife.circular2151.estructurasalida.Circular2151;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by Blueprints on 7/21/2015.
 */

@Stateless(name = "CirTabSabEjb")
@LocalBean
public class CirTabSabDAO {

    @PersistenceContext(unitName="CircularJPA")
    private EntityManager em;

    public List<CirTabSab2151> findAll() {
        return em.createQuery("select c from CirTabSab2151 c",CirTabSab2151.class).getResultList();
    }

    public List<CirTabSab2151> findByYear(String year){
        Query query = em.createQuery("select c from CirTabSab2151 c where SUBSTRING(c.periodo, 1, 4) = :year", CirTabSab2151.class);

        query.setParameter("year", year);

        return query.getResultList();
    }

    public List<Circular2151> findPrimaData(String periodo, String lineaDeNegocio, String origen){
        List<Object> list;
        Query query = null;

        if(periodo.length() == 4){
            query = em.createQuery("select c.rutCia, c.canalventa, c.poliza, c.codProd, c.dscProd, c.codFecu, c.codPol, c.codCad, sum(c.prima), sum(c.primaPs), c.aprobado" +
                    " from CirTabSab2151 c where c.lineaNegocio = :lineaDeNegocio and c.periodo like :periodo  and c.origen = :origen and c.tipoDato = :tipoDato" +
                    " group by c.rutCia, c.canalventa, c.poliza, c.codProd, c.dscProd, c.codFecu, c.codPol, c.codCad, c.aprobado");

            query.setParameter("periodo", periodo.substring(0, 4) + '%');

        } else if(periodo.length() > 4){
            query = em.createQuery("select c.rutCia, c.canalventa, c.poliza, c.codProd, c.dscProd, c.codFecu, c.codPol, c.codCad, sum(c.prima), sum(c.primaPs), c.aprobado" +
                    " from CirTabSab2151 c where c.periodo = :periodo and c.lineaNegocio = :lineaDeNegocio and c.origen = :origen and c.tipoDato = :tipoDato" +
                    " group by c.rutCia, c.canalventa, c.poliza, c.codProd, c.dscProd, c.codFecu, c.codPol, c.codCad, c.aprobado");

            query.setParameter("periodo", periodo);
        }

        query.setParameter("lineaDeNegocio", lineaDeNegocio);
        query.setParameter("origen", origen);
        query.setParameter("tipoDato", "P");

        list = query.getResultList();

        List<Circular2151> response = new ArrayList<Circular2151>();
        for (Object obj : list) {
            Object[] tupla = (Object[])obj;

            Circular2151 cir = new Circular2151();
            cir.setRut((String) tupla[0]);
            cir.setCanal_venta((String) tupla[1]);
            cir.setPoliza((String) tupla[2]);
            cir.setCod_prod((String) tupla[3]);
            cir.setDsc_prod((String) tupla[4]);
            cir.setCod_fecu((String) tupla[5]);
            cir.setCod_pol((String) tupla[6]);
            cir.setCod_cad((String) tupla[7]);

            if(tupla[8] instanceof Double) {
                cir.setPrima_uf((Double)tupla[8]);
            } else if(tupla[8] instanceof Long) {
                Long l = (Long)tupla[8];
                cir.setPrima_uf(l.doubleValue());
            } else {
                Object oo = tupla[8];
                cir.setPrima_uf((Double)oo);
            }

            if(tupla[9] instanceof Double) {
                cir.setPrima_pesos((Double)tupla[9]);
            } else if(tupla[9] instanceof Long) {
                Long l = (Long)tupla[9];
                cir.setPrima_pesos(l.doubleValue());
            } else {
                Object oo = tupla[9];
                cir.setPrima_pesos((Double)oo);
            }

            if(tupla[10]!=null && tupla[10].equals("S")){
                cir.setConfirmed(true);
            } else {
                cir.setConfirmed(false);
            }

            response.add(cir);
        }

        return response;
    }

    public List<Circular2151> findReservaData(String periodo, String lineaDeNegocio, String origen){
        List<Object> list;
        Query query = null;

        if(periodo.length() == 4){
            query = em.createQuery("select c.rutCia, c.canalventa, c.poliza, c.codProd, c.dscProd, c.codFecu, c.codPol, c.codCad, sum(c.reserva), sum(c.reservasNetaPs), c.aprobado" +
                    " from CirTabSab2151 c where c.periodo = :periodo and c.lineaNegocio = :lineaDeNegocio and c.origen = :origen and c.tipoDato = :tipoDato" +
                    " group by c.rutCia, c.canalventa, c.poliza, c.codProd, c.dscProd, c.codFecu, c.codPol, c.codCad, c.aprobado");


            query.setParameter("periodo", periodo.substring(0, 4) + '%');

        } else if(periodo.length() > 4){
            query = em.createQuery("select c.rutCia, c.canalventa, c.poliza, c.codProd, c.dscProd, c.codFecu, c.codPol, c.codCad, sum(c.reserva), sum(c.reservasNetaPs), c.aprobado" +
                    " from CirTabSab2151 c where c.periodo = :periodo and c.lineaNegocio = :lineaDeNegocio and c.origen = :origen and c.tipoDato = :tipoDato" +
                    " group by c.rutCia, c.canalventa, c.poliza, c.codProd, c.dscProd, c.codFecu, c.codPol, c.codCad, c.aprobado");


            query.setParameter("periodo", periodo);
        }

        query.setParameter("lineaDeNegocio", lineaDeNegocio);
        query.setParameter("origen", origen);
        query.setParameter("tipoDato", "R");

        list = query.getResultList();

        List<Circular2151> response = new ArrayList<Circular2151>();
        for (Object obj : list) {
            Object[] tupla = (Object[])obj;

            Circular2151 cir = new Circular2151();
            cir.setRut((String) tupla[0]);
            cir.setCanal_venta((String) tupla[1]);
            cir.setPoliza((String) tupla[2]);
            cir.setCod_prod((String) tupla[3]);
            cir.setDsc_prod((String) tupla[4]);
            cir.setCod_fecu((String) tupla[5]);
            cir.setCod_pol((String) tupla[6]);
            cir.setCod_cad((String) tupla[7]);

            if(tupla[8] instanceof Double) {
                cir.setPrima_uf((Double)tupla[8]);
            } else if(tupla[8] instanceof Long) {
                Long l = (Long)tupla[8];
                cir.setPrima_uf(l.doubleValue());
            } else {
                Object oo = tupla[8];
                cir.setPrima_uf((Double)oo);
            }

            if(tupla[9] instanceof Double) {
                cir.setPrima_pesos((Double)tupla[9]);
            } else if(tupla[9] instanceof Long) {
                Long l = (Long)tupla[9];
                cir.setPrima_pesos(l.doubleValue());
            } else {
                Object oo = tupla[9];
                cir.setPrima_pesos((Double)oo);
            }

            if(tupla[10]!=null && tupla[10].equals("S")){
                cir.setConfirmed(true);
            } else {
                cir.setConfirmed(false);
            }

            response.add(cir);
        }

        return response;
    }

    public void confirmData(String periodo, String lineaDeNegocio, String origen){

        Query query = em.createQuery("select c from CirTabSab2151 c where c.periodo = :periodo and c.lineaNegocio = :lineaDeNegocio and c.origen = :origen", CirTabSab2151.class);

        query.setParameter("periodo", periodo);
        query.setParameter("lineaDeNegocio", lineaDeNegocio);
        query.setParameter("origen", origen);

        List<CirTabSab2151> listaAConfirmar = query.getResultList();

        if ( listaAConfirmar == null )
            throw new IllegalArgumentException("list can't be null");

        for (CirTabSab2151 cirTabSab2151 : listaAConfirmar) {
            cirTabSab2151.setAprobado("S");
            em.merge(cirTabSab2151);
        }

        em.flush();
    }

    public boolean isApproved(String periodo, String lineaDeNegocio, String origen){
        boolean response = false;

        Query query = em.createQuery("select c from CirTabSab2151 c where c.periodo = :periodo and c.lineaNegocio = :lineaDeNegocio and c.origen = :origen", CirTabSab2151.class);

        query.setParameter("periodo", periodo);
        query.setParameter("lineaDeNegocio", lineaDeNegocio);
        query.setParameter("origen", origen);

        List<CirTabSab2151> listaAConfirmar = query.getResultList();

        if ( listaAConfirmar == null )
            throw new IllegalArgumentException("list can't be null");

        for (CirTabSab2151 cirTabSab2151 : listaAConfirmar) {
            if(cirTabSab2151.getAprobado().equals("S")){
                response = true;
                return true;
            }
        }

        return response;
    }

    public CirTabSab2151 findById(Long id){
        return em.find(CirTabSab2151.class, id);
    }

    public List<String> findBusinessLinesCodes(){
        return em.createQuery("select DISTINCT(c.lineaNegocio) from CirTabSab2151 c where c.lineaNegocio is not null").getResultList();
    }

    public List<String> findBusinessLinesCodesByAno(String ano){
        return em.createQuery("select DISTINCT(c.lineaNegocio) from CirTabSab2151 c where c.lineaNegocio is not null\n" +
                "and c.periodo LIKE :ano").setParameter("ano", ano + "%").getResultList();
    }

    public List<String> findOriginsByLineaAndAno(String linea, String ano){
        Query queryNative = em.createNativeQuery("select DISTINCT(c.ORIGEN) from CIR_TAB_SAB2151 c where c.LINEA_NEGOCIO='"+linea+"' and c.PERIODO LIKE '"+ano+"%'");

        return queryNative.getResultList();

        /*
        return em.createQuery("select DISTINCT(c.origen) from CirTabSab2151 c where c.periodo LIKE :ano and c.lineaNegocio = :linea")
                .setParameter("ano", "%" + ano + "%").setParameter("linea", linea).getResultList();*/
    }

    public List<String> findOriginCodes(){
        return em.createQuery("select DISTINCT(c.origen) from CirTabSab2151 c where c.origen is not null").getResultList();
    }

    public List<String> findAllPeriods(){
        return em.createQuery("select DISTINCT(c.periodo) from CirTabSab2151 c where c.periodo is not null").getResultList();
    }

    public List<String> findAllLineasDeNegocio(){
        return em.createQuery("select DISTINCT(c.linea) from CirTabSab2151 c where c.linea is not null").getResultList();
    }

    public HashMap<String, ResumenLineaDeNegocio> findDataByPeriodo(String ano, String mes){
        List<Object> list;

        Query queryNative = em.createNativeQuery("SELECT count(*) as total,\n" +
                "  sum( case when  aprobado = 'S' then 1 else 0 end ) as aprobadas,\n" +
                "  sum( case when  aprobado = 'N' then 1 else 0 end ) as noAprobadas, \n" +
                "  count(aprobado)as marcados, \n" +
                "  LINEA\n" +
                "FROM CIR_TAB_SAB2151 \n" +
                "WHERE PERIODO = '" + ano + mes + "' \n" +
                "GROUP BY LINEA\n");

        /*
        Query query = em.createQuery("select count(c) as total," +
                "  sum(case when c.aprobado = 'S' then 1 else 0 end) as aprobadas," +
                "  sum(case when  aprobado = 'N' then 1 else 0 end) as noAprobadas," +
                "  count(aprobado)as marcados, c.linea from CirTabSab2151 c" +
                "  where c.periodo = '201401' \n" +
                "  group by LINEA"); */

        list = queryNative.getResultList();
        HashMap<String, ResumenLineaDeNegocio> hashMap =  new HashMap<String, ResumenLineaDeNegocio>();

        for (Object o : list) {
            Object[] tupla = (Object[])o;

            ResumenLineaDeNegocio res = new ResumenLineaDeNegocio();
            res.setTotal(((BigDecimal) tupla[0]).longValue());
            res.setAprobados(((BigDecimal) tupla[1]).longValue());
            res.setNoAprobados(((BigDecimal) tupla[2]).longValue());
            res.setMarcados(((BigDecimal) tupla[3]).longValue());

            hashMap.put((String) tupla[4], res);
        }

        return hashMap;
    }

    public void create(CirTabSab2151 obj) {
        em.persist(obj);

        //se debe hacer flush para garantizar la creacion del ID
        em.flush();
    }

    public int countAll() {
        Number res = (Number) em.createQuery("select count(c) from CirTabSab2151 c").getSingleResult();
        return res.intValue();
    }

}
