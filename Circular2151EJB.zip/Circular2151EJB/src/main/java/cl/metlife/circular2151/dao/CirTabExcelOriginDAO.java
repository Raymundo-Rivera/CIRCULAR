package cl.metlife.circular2151.dao;

import cl.metlife.circular2151.entity.CirTabExcelOrigenCir2151;
import cl.metlife.circular2151.entity.CirTabSab2151;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

/**
 * Created by Blueprints on 7/24/2015.
 */
@Stateless(name = "CirTabSabExcelEjb")
@LocalBean
public class CirTabExcelOriginDAO {

    @PersistenceContext(unitName="CircularJPA")
    private EntityManager em;

    public CirTabExcelOrigenCir2151 create(CirTabExcelOrigenCir2151 obj) {

        em.persist(obj);

        //se debe hacer flush para garantizar la creacion del ID
        em.flush();

        return obj;

    }

    public List<CirTabExcelOrigenCir2151> findAll() {
        return em.createQuery("select c from CirTabExcelOrigenCir2151 c",CirTabExcelOrigenCir2151.class).getResultList();
    }

    public boolean delete(CirTabExcelOrigenCir2151 obj){
        CirTabExcelOrigenCir2151 toDelete = em.find(CirTabExcelOrigenCir2151.class,obj.getCirTabExcelOrigenCir2151());

        if(toDelete==null)
            return false;

        for (CirTabSab2151 element : toDelete.getCirTabSab2151s()) {
            em.remove(element);
        }

        em.remove(toDelete);
        return true;
    }
}
