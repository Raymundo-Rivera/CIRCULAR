package cl.metlife.circular2151.dao;

import cl.metlife.circular2151.beans.PRT;
import cl.metlife.circular2151.entity.CirTabCir2151;
import org.apache.commons.lang3.StringEscapeUtils;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.sql.DataSource;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by Ivan on 15-01-2015.
 */
@Stateless(name = "CircularDaoEjb")
@LocalBean
public class CircularDAO {
    @PersistenceContext(unitName="CircularJPA")
    private EntityManager em;

    public List<CirTabCir2151> findByYear(String year){
        Query query = em.createQuery("select c from CirTabCir2151 c where SUBSTRING(c.periodo, 1, 4) = :year", CirTabCir2151.class);

        query.setParameter("year", year);

        List<CirTabCir2151> list = query.getResultList();
        return list;
    }

    /*public List<CirTabCir2151> getAllEntries() {
        Query q = em.createQuery("SELECT c FROM CirTabCir2151 c");
        List<CirTabCir2151> datos = q.getResultList();

        return datos;

    }*/

    public PRT getAllEntries(){
        DataSource ds;
        PRT result = new PRT();
        try {
            Context ctx = new InitialContext();
            ds = (DataSource)ctx.lookup("jdbc/CircularDS");

            PreparedStatement statement = ds.getConnection().prepareStatement("SELECT * FROM CIR_TAB_CIR2151 WHERE CIR_TAB_CIR2151.ENVIADO = 'N'");
            ResultSet rs = statement.executeQuery();


            List<PRT.Registro> registros = result.getRegistro();
            int registroId = 1;
            while (rs.next()) {
                PRT.Registro reg = new PRT.Registro();
                String periodo = rs.getString("PERIODO");
                periodo = periodo.substring(0,4);
                //String lineaDeNegocios = rs.getString("LINEA_DE_NEGOCIOS");
                String origen = rs.getString("ORIGEN");
                String base = rs.getString("BASE");
                int grupo = rs.getInt("GRUPO");
                String cad = rs.getString("COD");
                if(cad == null) {
                    cad = "";
                }

                reg.setCodigoUnico(registroId++);
                reg.setFormaReserva(this.getEscapedString(rs, "CIRC_COD_FORMA_RES"));
                reg.setGrupoCia(grupo);//valores validos: "1" o bien "2";
                reg.setLineasNegocio(this.getEscapedString(rs, "LINEA_DE_NEGOCIOS"));
                reg.setNombreProducto(this.getEscapedString(rs, "DESC_PROD"));
                reg.setPeriodo(Integer.parseInt(periodo));
                reg.setPlazoSeguro(this.getEscapedString(rs, "CIRC_PLAZO_SEGURO"));
                reg.setPoliza(this.getEscapedString(rs, "POL").replaceAll(" ", ""));
                reg.setPrimaDirecta(rs.getLong("PRIMA"));
                reg.setRamoCia(this.getEscapedString(rs, "RAMO_CIA"));
                reg.setRamoEstFinanciero(rs.getInt("RAMO_ESTADO_FINAN"));
                reg.setReservaTecnicaBruta(rs.getLong("RESERVA_BRUTA"));
                reg.setReservaTecnicaNeta(rs.getLong("RESERVA_NETA"));

                //RUT_CIA
                String rut = this.getEscapedString(rs, "RUT_CIA");
                rut = rut.replace("-", "").replace(" ", "").replace(".", "");
                reg.setRutCia(rut);

                reg.setTablaMor(this.getEscapedString(rs, "CIRC_TABLA_MORTALIDAD"));
                if(reg.getTablaMor()==null) {
                    reg.setTablaMor("");
                }

/*
Favor  puedes Cambia el nombre del campo Clausulas, por CAD/CAL , y ahí va el valor del campo COD de la tabla CIRC_TABLA_MORTALIDAD.

 */

                reg.setClausula(this.getClausulas(cad));

                registros.add(reg);
            }


        } catch (NamingException e) {
            e.printStackTrace();

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }

    private List<PRT.Registro.Clausula> getClausulas(String cad) {
        List<String> clausulas = Arrays.asList(cad.split(","));
        List<PRT.Registro.Clausula> out = new ArrayList<PRT.Registro.Clausula>(clausulas.size());

        for(String clausula : clausulas) {
            if(!clausula.equals("")) {
                PRT.Registro.Clausula c = new PRT.Registro.Clausula();
                c.setNumero(clausula.trim().replaceAll(" ", ""));
                out.add(c);
            }
        }
        return out;
    }

    private String getEscapedString(ResultSet rs, String columnName) throws SQLException {
        String val = rs.getString(columnName);

        if(val != null) {
            val = val.replace("\t", "");
            return StringEscapeUtils.escapeHtml3(val).trim();
        }
        return "";
    }

    public String getCircularJson() {
        String result = "";
        PRT c = this.getAllEntries();

        result += "{\"Result\":\"OK\", ";

        result+="\"Records\":[";
        boolean first = true;
        for(PRT.Registro r : c.getRegistro()) {
            if(first == true) {
                first=false;
            }
            else {
                result += ",";
            }
            result += "{\"CodigoUnico\":" + "\"" + r.getCodigoUnico()+ "\"";
            result += ",\"RutCia\":" + "\"" + r.getRutCia() + "\"";
            result += ",\"GrupoCia\":" + "\"" + r.getGrupoCia() + "\"";
            result += ",\"Periodo\":" + "\"" + r.getPeriodo() + "\"";
            result += ",\"LineasNegocio\":" + "\"" + r.getLineasNegocio() + "\"";
            result += ",\"RamoEstFinanciero\":" + "\"" + r.getRamoEstFinanciero() + "\"";
            result += ",\"RamoCia\":" + "\"" + r.getRamoCia() + "\"";
            result += ",\"NombreProducto\":" + "\"" + r.getNombreProducto() + "\"";
            result += ",\"Poliza\":" + "\"" + r.getPoliza() + "\"";
            result += ",\"Clausulas\":" + "\"" + this.clausulasToString(r) + "\"";



            result += ",\"PrimaDirecta\":" + "\"" + r.getPrimaDirecta() + "\"";
            result += ",\"FormaReserva\":" + "\"" + r.getFormaReserva() + "\"";
            result += ",\"ReservaTecnicaBruta\":" + "\"" + r.getReservaTecnicaBruta() + "\"";
            result += ",\"ReservaTecnicaNeta\":" + "\"" + r.getReservaTecnicaNeta() + "\"";
            result += ",\"PlazoSeguro\":" + "\"" + r.getPlazoSeguro() + "\"";
            result += ",\"TablaMor\":" + "\"" + r.getTablaMor() + "\"}";
        }

        result += "],";
        result += "\"TotalRecordCount\":"+ c.getRegistro().size();
        result += "}";

        return result;
    }

    private String clausulasToString(PRT.Registro r){
        boolean first = true;
        String res = "";
        for(PRT.Registro.Clausula c : r.getClausula()){
            if(first) {
                first = false;
            }
            else {
                res += ", ";
            }
            String cl = c.getNumero();
            cl = cl.replace(" ", "");
            cl = cl.replace("\t", "");
            res += cl;
        }
        return res;
    }


}

